<?php
/**
 * Plugin Name: Hippo CRM
 * Description: Backend del CRM de The Hipposoft: custom post types, API REST hippo/v1 (crm.thehipposoft.com) y meta boxes del admin.
 * Version:     1.3.0
 * Author:      The Hipposoft
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

const HIPPO_CRM_ARCHIVOS = [
    'helpers', 'cpt', 'rutas',
    'clientes', 'link-publico', 'proyectos', 'pagos', 'tareas', 'unidades', 'costos', 'pagos-costo', 'propuestas', 'archivos', 'app-passwords', 'portal',
    'cors', 'admin',
];

// Se carga después del theme: si el functions.php todavía tiene el código del CRM,
// el plugin no se carga (evita el "Cannot redeclare") y avisa en el admin.
add_action('after_setup_theme', function () {
    if (function_exists('hippo_crm_login')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-warning"><p><strong>Hippo CRM:</strong> el código del CRM sigue en el <code>functions.php</code> del theme, así que el plugin no se cargó. Borrá la sección "HIPPO CRM IMPLEMENTACIÓN" del theme.</p></div>';
        });
        return;
    }
    foreach (HIPPO_CRM_ARCHIVOS as $archivo) {
        require_once __DIR__ . '/includes/' . $archivo . '.php';
    }
}, 1);
