<?php
// Hippo CRM — Custom post types

if (!defined('ABSPATH')) exit;

add_action('init', function () {
    register_post_type('hippo_cliente', [
        'labels'       => ['name' => 'Clientes CRM', 'singular_name' => 'Cliente CRM'],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'supports'     => ['title'],
        'menu_icon'    => 'dashicons-groups',
    ]);

    register_post_type('hippo_proyecto', [
        'labels'       => ['name' => 'Proyectos CRM', 'singular_name' => 'Proyecto CRM'],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'supports'     => ['title'],
        'menu_icon'    => 'dashicons-portfolio',
    ]);

    register_post_type('hippo_pago', [
        'labels'       => ['name' => 'Pagos CRM', 'singular_name' => 'Pago CRM'],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'supports'     => ['title'],
        'menu_icon'    => 'dashicons-money-alt',
    ]);

    register_post_type('hippo_costo', [
        'labels'       => ['name' => 'Costos CRM', 'singular_name' => 'Costo CRM'],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'supports'     => ['title'],
        'menu_icon'    => 'dashicons-chart-area',
    ]);

    // Unidades que se cobran por mes en un proyecto (ej. casillas de correo).
    // Se administran desde el CRM; acá no tienen pantalla propia.
    // Tareas internas del equipo (to-do). Se administran desde el CRM.
    // Pagos hechos de un costo (sueldos, suscripciones…). Se administran desde el CRM.
    register_post_type('hippo_pago_costo', [
        'labels'   => ['name' => 'Pagos de costos CRM', 'singular_name' => 'Pago de costo CRM'],
        'public'   => false,
        'show_ui'  => false,
        'supports' => ['title'],
    ]);

    register_post_type('hippo_tarea', [
        'labels'   => ['name' => 'Tareas CRM', 'singular_name' => 'Tarea CRM'],
        'public'   => false,
        'show_ui'  => false,
        'supports' => ['title', 'editor'],
    ]);

    register_post_type('hippo_unidad', [
        'labels'   => ['name' => 'Unidades CRM', 'singular_name' => 'Unidad CRM'],
        'public'   => false,
        'show_ui'  => false,
        'supports' => ['title'],
    ]);

    // Propuestas, plantillas y cuentas: se editan desde el CRM (los datos van en JSON)
    foreach ([
        'hippo_propuesta'    => ['Propuestas CRM', 'Propuesta CRM', 'dashicons-media-document'],
        'hippo_plantilla'    => ['Plantillas CRM', 'Plantilla CRM', 'dashicons-media-text'],
        'hippo_cuenta_banco' => ['Cuentas bancarias CRM', 'Cuenta bancaria CRM', 'dashicons-bank'],
    ] as $tipo => [$plural, $singular, $icono]) {
        register_post_type($tipo, [
            'labels'       => ['name' => $plural, 'singular_name' => $singular],
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => true,
            'supports'     => ['title'],
            'menu_icon'    => $icono,
        ]);
    }

    // Accesos al portal de clientes: solo se manejan desde el CRM
    register_post_type('hippo_acceso', [
        'labels'   => ['name' => 'Accesos al portal', 'singular_name' => 'Acceso al portal'],
        'public'   => false,
        'show_ui'  => false,
        'supports' => ['title'],
    ]);

    // Archivos de proyectos: solo se manejan desde el CRM
    register_post_type('hippo_archivo', [
        'labels'   => ['name' => 'Archivos CRM', 'singular_name' => 'Archivo CRM'],
        'public'   => false,
        'show_ui'  => false,
        'supports' => ['title'],
    ]);
});
