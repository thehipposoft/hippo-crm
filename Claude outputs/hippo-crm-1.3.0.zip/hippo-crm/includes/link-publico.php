<?php
// Hippo CRM — Link público del estado de cuenta

if (!defined('ABSPATH')) exit;

// Cada cliente puede tener un token (meta 'token_publico'). Con ese token cualquiera ve
// su estado de cuenta sin login: por eso la respuesta no incluye notas ni acciones internas.

function hippo_crm_generar_link_publico($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cliente');
    if (!$post) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);

    // Uno nuevo reemplaza al anterior, que deja de funcionar
    $token = bin2hex(random_bytes(32));
    update_post_meta($post->ID, 'token_publico', $token);
    return new WP_REST_Response(['token' => $token], 201);
}

function hippo_crm_revocar_link_publico($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cliente');
    if (!$post) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);

    delete_post_meta($post->ID, 'token_publico');
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_estado_publico($request) {
    $token = (string) $request->get_param('token');
    $clientes = get_posts([
        'post_type' => 'hippo_cliente', 'numberposts' => 1,
        'meta_key' => 'token_publico', 'meta_value' => $token,
    ]);
    if (empty($clientes) || !hash_equals((string) get_post_meta($clientes[0]->ID, 'token_publico', true), $token)) {
        return new WP_REST_Response(['error' => 'Link inválido'], 404);
    }
    $respuesta = new WP_REST_Response(hippo_crm_estado_de_cliente($clientes[0]), 200);
    $respuesta->header('Cache-Control', 'no-store');
    return $respuesta;
}

// Lo que ve el cliente (link público y portal): sin notas, acciones internas ni archivos
function hippo_crm_estado_de_cliente($cliente) {
    $proyectos = get_posts([
        'post_type' => 'hippo_proyecto', 'numberposts' => -1,
        'meta_key' => 'cliente_id', 'meta_value' => $cliente->ID,
    ]);
    $ids = wp_list_pluck($proyectos, 'ID');
    $pagos = empty($ids) ? [] : get_posts([
        'post_type' => 'hippo_pago', 'numberposts' => -1,
        'meta_query' => [['key' => 'proyecto_id', 'value' => $ids, 'compare' => 'IN']],
    ]);

    $datos_cliente = hippo_crm_cliente_to_array($cliente);
    return [
        'cliente' => [
            'nombre'        => $datos_cliente['nombre'],
            'contacto'      => $datos_cliente['contacto'] ?: null,
            'emailContacto' => $datos_cliente['emailContacto'] ?: null,
            'pais'          => $datos_cliente['pais'] ?: null,
        ],
        'proyectos' => array_map(function ($p) {
            $datos = hippo_crm_proyecto_to_array($p);
            $datos['accionPendiente'] = null;
            $datos['archivos'] = [];
            unset($datos['propuestaEnviada'], $datos['propuestaAprobada']);
            $datos['unidades'] = array_map(function ($u) {
                $u['notas'] = null;
                return $u;
            }, $datos['unidades']);
            return $datos;
        }, $proyectos),
        'pagos' => array_map(function ($p) {
            $datos = hippo_crm_pago_to_array($p);
            $datos['notas'] = null;
            return $datos;
        }, $pagos),
    ];
}
