<?php
// Hippo CRM — Portal de clientes (estado de cuenta con usuario y contraseña)

if (!defined('ABSPATH')) exit;

// Los accesos NO son usuarios de WordPress (no pueden entrar a wp-admin): son posts
// 'hippo_acceso' de un cliente, con contraseña propia. Varias personas por cliente.
// Flujo: el equipo invita desde el CRM → llega un email → la persona crea su contraseña.
// Los tokens (invitación, recuperar contraseña, sesión) se guardan hasheados.

const HIPPO_CRM_ACCESO_ESTADOS     = ['INVITADO', 'ACTIVO', 'DESACTIVADO'];
const HIPPO_CRM_PORTAL_MIN_CLAVE   = 8;
const HIPPO_CRM_PORTAL_SESION_DIAS = 30;
const HIPPO_CRM_PORTAL_INVITACION_DIAS = 7;
const HIPPO_CRM_PORTAL_RESET_SEG   = HOUR_IN_SECONDS;
const HIPPO_CRM_PORTAL_MAX_FALLOS  = 5;
const HIPPO_CRM_PORTAL_BLOQUEO_SEG = 15 * MINUTE_IN_SECONDS;
const HIPPO_CRM_PORTAL_MAX_RESETS_HORA = 3;
const HIPPO_CRM_PORTAL_MAX_SESIONES = 10;

function hippo_crm_portal_url($ruta = '') {
    $base = defined('HIPPO_CRM_URL') ? HIPPO_CRM_URL : 'https://crm.thehipposoft.com';
    return rtrim($base, '/') . '/portal' . $ruta;
}

function hippo_crm_hash_token($token) {
    return hash('sha256', (string) $token);
}

function hippo_crm_normalizar_email($email) {
    return strtolower(trim(sanitize_email((string) $email)));
}

function hippo_crm_acceso_to_array($post) {
    return [
        'id'           => $post->ID,
        'clienteId'    => (int) get_post_meta($post->ID, 'cliente_id', true),
        'nombre'       => $post->post_title,
        'email'        => get_post_meta($post->ID, 'email', true),
        'estado'       => get_post_meta($post->ID, 'estado', true) ?: 'INVITADO',
        'invitadoEl'   => get_post_meta($post->ID, 'invitado_el', true) ?: null,
        'ultimoAcceso' => get_post_meta($post->ID, 'ultimo_acceso', true) ?: null,
    ];
}

function hippo_crm_acceso_por_email($email) {
    $posts = get_posts(['post_type' => 'hippo_acceso', 'numberposts' => 1, 'meta_key' => 'email', 'meta_value' => hippo_crm_normalizar_email($email)]);
    return $posts[0] ?? null;
}

function hippo_crm_acceso_por_token($tipo, $token) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string) $token)) return null;
    $hash = hippo_crm_hash_token($token);
    $posts = get_posts(['post_type' => 'hippo_acceso', 'numberposts' => 1, 'meta_key' => $tipo . '_hash', 'meta_value' => $hash]);
    if (empty($posts)) return null;
    $expira = (int) get_post_meta($posts[0]->ID, $tipo . '_expira', true);
    return $expira >= time() ? $posts[0] : null;
}

// Idioma de los emails según el país del cliente (igual que los documentos del CRM)
function hippo_crm_idioma_cliente($cliente_id) {
    $pais = (string) get_post_meta($cliente_id, 'pais', true);
    if (trim($pais) === '') return 'es';
    return preg_match('/argentin|urugua|chile|parag|bolivi|per[uú]|ecuador|colombi|venezuel|m[eé]xic|espa[nñ]|spain|guatemal|hondur|salvador|nicaragu|costa rica|panam|cuba|dominican|puerto rico/i', $pais) ? 'es' : 'en';
}

function hippo_crm_portal_email($acceso, $tipo, $token) {
    $cliente_id = (int) get_post_meta($acceso->ID, 'cliente_id', true);
    $cliente = get_post($cliente_id);
    $en = hippo_crm_idioma_cliente($cliente_id) === 'en';
    $nombre = $acceso->post_title;
    $email = get_post_meta($acceso->ID, 'email', true);

    if ($tipo === 'invitacion') {
        $link = hippo_crm_portal_url('/activar?token=' . $token);
        $asunto = $en ? 'Your Hippo client portal access' : 'Tu acceso al portal de clientes de Hippo';
        $cuerpo = $en
            ? "Hi {$nombre},\n\nWe created your access to the Hippo client portal" . ($cliente ? " for {$cliente->post_title}" : '') . ". There you can see your payments, balance, upcoming installments and proposals, and download your statement of account.\n\nCreate your password here (the link is valid for " . HIPPO_CRM_PORTAL_INVITACION_DIAS . " days):\n{$link}\n\nYour username is this email address: {$email}\n\nThe Hippo team"
            : "Hola {$nombre}:\n\nTe creamos un acceso al portal de clientes de Hippo" . ($cliente ? " para {$cliente->post_title}" : '') . ". Ahí vas a poder ver tus pagos, el saldo, las próximas cuotas y las propuestas, y descargar tu estado de cuenta.\n\nCreá tu contraseña acá (el link vale " . HIPPO_CRM_PORTAL_INVITACION_DIAS . " días):\n{$link}\n\nTu usuario es este email: {$email}\n\nEl equipo de Hippo";
    } else {
        $link = hippo_crm_portal_url('/restablecer?token=' . $token);
        $asunto = $en ? 'Reset your Hippo portal password' : 'Cambiá tu contraseña del portal de Hippo';
        $cuerpo = $en
            ? "Hi {$nombre},\n\nSomeone asked to reset your Hippo client portal password. If it was you, choose a new one here (valid for 1 hour):\n{$link}\n\nIf it wasn't you, ignore this email.\n\nThe Hippo team"
            : "Hola {$nombre}:\n\nPidieron cambiar tu contraseña del portal de clientes de Hippo. Si fuiste vos, elegí una nueva acá (vale 1 hora):\n{$link}\n\nSi no fuiste vos, ignorá este email.\n\nEl equipo de Hippo";
    }
    return wp_mail($email, $asunto, $cuerpo);
}

function hippo_crm_nuevo_token_acceso($acceso_id, $tipo, $segundos) {
    $token = bin2hex(random_bytes(32));
    update_post_meta($acceso_id, $tipo . '_hash', hippo_crm_hash_token($token));
    update_post_meta($acceso_id, $tipo . '_expira', time() + $segundos);
    return $token;
}

function hippo_crm_borrar_token_acceso($acceso_id, $tipo) {
    delete_post_meta($acceso_id, $tipo . '_hash');
    delete_post_meta($acceso_id, $tipo . '_expira');
}

// ==== Sesiones del portal ====

function hippo_crm_portal_crear_sesion($acceso_id) {
    // Limpia vencidas y deja como máximo las últimas N
    $hashes = get_post_meta($acceso_id, 'sesion_hash', false);
    $vigentes = [];
    foreach ($hashes as $h) {
        if ((int) get_post_meta($acceso_id, 'sesion_exp_' . $h, true) >= time()) $vigentes[] = $h;
        else hippo_crm_portal_borrar_sesion($acceso_id, $h);
    }
    while (count($vigentes) >= HIPPO_CRM_PORTAL_MAX_SESIONES) hippo_crm_portal_borrar_sesion($acceso_id, array_shift($vigentes));

    $token = bin2hex(random_bytes(32));
    $hash = hippo_crm_hash_token($token);
    add_post_meta($acceso_id, 'sesion_hash', $hash);
    update_post_meta($acceso_id, 'sesion_exp_' . $hash, time() + HIPPO_CRM_PORTAL_SESION_DIAS * DAY_IN_SECONDS);
    update_post_meta($acceso_id, 'ultimo_acceso', hippo_crm_ahora_utc());
    return $token;
}

function hippo_crm_portal_borrar_sesion($acceso_id, $hash) {
    delete_post_meta($acceso_id, 'sesion_hash', $hash);
    delete_post_meta($acceso_id, 'sesion_exp_' . $hash);
}

function hippo_crm_portal_borrar_sesiones($acceso_id) {
    foreach (get_post_meta($acceso_id, 'sesion_hash', false) as $h) hippo_crm_portal_borrar_sesion($acceso_id, $h);
}

// Acceso ACTIVO dueño del token de sesión (header Authorization: Bearer), o null
function hippo_crm_portal_acceso_de($request) {
    $auth = (string) $request->get_header('authorization');
    if (!preg_match('/^Bearer\s+([a-f0-9]{64})$/', $auth, $m)) return null;
    $hash = hippo_crm_hash_token($m[1]);
    $posts = get_posts(['post_type' => 'hippo_acceso', 'numberposts' => 1, 'meta_key' => 'sesion_hash', 'meta_value' => $hash]);
    if (empty($posts)) return null;
    $acceso = $posts[0];
    if ((int) get_post_meta($acceso->ID, 'sesion_exp_' . $hash, true) < time()) return null;
    if (get_post_meta($acceso->ID, 'estado', true) !== 'ACTIVO') return null;
    return $acceso;
}

function hippo_crm_portal_check($request) {
    return hippo_crm_portal_acceso_de($request) !== null;
}

function hippo_crm_validar_clave($clave) {
    return is_string($clave) && mb_strlen($clave) >= HIPPO_CRM_PORTAL_MIN_CLAVE;
}

function hippo_crm_respuesta_sesion($acceso) {
    $cliente = get_post((int) get_post_meta($acceso->ID, 'cliente_id', true));
    return [
        'token'   => hippo_crm_portal_crear_sesion($acceso->ID),
        'nombre'  => $acceso->post_title,
        'cliente' => $cliente ? $cliente->post_title : null,
    ];
}

// ==== CRM (con login del equipo) ====

function hippo_crm_get_accesos($request) {
    $cliente = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cliente');
    if (!$cliente) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);
    $posts = get_posts(['post_type' => 'hippo_acceso', 'numberposts' => -1, 'meta_key' => 'cliente_id', 'meta_value' => $cliente->ID, 'orderby' => 'date', 'order' => 'ASC']);
    return new WP_REST_Response(array_map('hippo_crm_acceso_to_array', $posts), 200);
}

function hippo_crm_invitar_acceso($request) {
    $cliente = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cliente');
    if (!$cliente) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);
    $params = $request->get_json_params() ?: [];
    $email = hippo_crm_normalizar_email($params['email'] ?? '');
    $nombre = sanitize_text_field($params['nombre'] ?? '');
    if (!is_email($email)) return new WP_REST_Response(['error' => 'Email inválido'], 400);
    if ($nombre === '') return new WP_REST_Response(['error' => 'El nombre es obligatorio'], 400);
    if (hippo_crm_acceso_por_email($email)) return new WP_REST_Response(['error' => 'Ese email ya tiene acceso al portal'], 409);

    $id = wp_insert_post(['post_type' => 'hippo_acceso', 'post_title' => $nombre, 'post_status' => 'publish']);
    update_post_meta($id, 'cliente_id', $cliente->ID);
    update_post_meta($id, 'email', $email);
    update_post_meta($id, 'estado', 'INVITADO');
    update_post_meta($id, 'invitado_el', hippo_crm_ahora_utc());
    $token = hippo_crm_nuevo_token_acceso($id, 'invitacion', HIPPO_CRM_PORTAL_INVITACION_DIAS * DAY_IN_SECONDS);
    $enviado = hippo_crm_portal_email(get_post($id), 'invitacion', $token);

    return new WP_REST_Response(hippo_crm_acceso_to_array(get_post($id)) + ['emailEnviado' => (bool) $enviado], 201);
}

// Reenvía la invitación (nuevo link; el anterior deja de valer). Solo si todavía no la aceptó.
function hippo_crm_reenviar_invitacion($request) {
    $acceso = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_acceso');
    if (!$acceso) return new WP_REST_Response(['error' => 'Acceso no encontrado'], 404);
    if (get_post_meta($acceso->ID, 'estado', true) !== 'INVITADO') {
        return new WP_REST_Response(['error' => 'Ya creó su contraseña: si la olvidó, que use "Olvidé mi contraseña"'], 409);
    }
    update_post_meta($acceso->ID, 'invitado_el', hippo_crm_ahora_utc());
    $token = hippo_crm_nuevo_token_acceso($acceso->ID, 'invitacion', HIPPO_CRM_PORTAL_INVITACION_DIAS * DAY_IN_SECONDS);
    $enviado = hippo_crm_portal_email($acceso, 'invitacion', $token);
    return new WP_REST_Response(hippo_crm_acceso_to_array(get_post($acceso->ID)) + ['emailEnviado' => (bool) $enviado], 200);
}

// Desactivar (corta sus sesiones) o volver a activar
function hippo_crm_update_acceso($request) {
    $acceso = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_acceso');
    if (!$acceso) return new WP_REST_Response(['error' => 'Acceso no encontrado'], 404);
    $params = $request->get_json_params() ?: [];
    $activo = $params['activo'] ?? null;
    if (!is_bool($activo)) return new WP_REST_Response(['error' => 'activo debe ser true o false'], 400);

    if (!$activo) {
        update_post_meta($acceso->ID, 'estado', 'DESACTIVADO');
        hippo_crm_portal_borrar_sesiones($acceso->ID);
        hippo_crm_borrar_token_acceso($acceso->ID, 'reset');
    } else {
        update_post_meta($acceso->ID, 'estado', get_post_meta($acceso->ID, 'clave_hash', true) ? 'ACTIVO' : 'INVITADO');
    }
    return new WP_REST_Response(hippo_crm_acceso_to_array(get_post($acceso->ID)), 200);
}

function hippo_crm_delete_acceso($request) {
    $acceso = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_acceso');
    if (!$acceso) return new WP_REST_Response(['error' => 'Acceso no encontrado'], 404);
    wp_delete_post($acceso->ID, true);
    return new WP_REST_Response(['success' => true], 200);
}

// ==== Portal (sin login de WordPress) ====

function hippo_crm_portal_login($request) {
    $params = $request->get_json_params() ?: [];
    $email = hippo_crm_normalizar_email($params['email'] ?? '');
    $clave = (string) ($params['password'] ?? '');
    $llave = 'hippo_crm_portal_fallos_' . md5($email);

    $fallos = (int) get_transient($llave);
    if ($fallos >= HIPPO_CRM_PORTAL_MAX_FALLOS) {
        return new WP_REST_Response(['error' => 'Demasiados intentos', 'codigo' => 'bloqueado'], 429);
    }

    $acceso = $email !== '' ? hippo_crm_acceso_por_email($email) : null;
    $hash = $acceso ? (string) get_post_meta($acceso->ID, 'clave_hash', true) : '';
    $estado = $acceso ? get_post_meta($acceso->ID, 'estado', true) : null;
    if (!$acceso || $hash === '' || !wp_check_password($clave, $hash)) {
        set_transient($llave, $fallos + 1, HIPPO_CRM_PORTAL_BLOQUEO_SEG);
        return new WP_REST_Response(['error' => 'Email o contraseña incorrectos', 'codigo' => 'credenciales'], 401);
    }
    if ($estado !== 'ACTIVO') {
        return new WP_REST_Response(['error' => 'Acceso desactivado', 'codigo' => 'desactivado'], 403);
    }

    delete_transient($llave);
    return new WP_REST_Response(hippo_crm_respuesta_sesion($acceso), 200);
}

// Datos para mostrar el form de invitación / nueva contraseña antes de enviarlo
function hippo_crm_portal_ver_token($request) {
    $tipo = $request->get_param('tipo') === 'reset' ? 'reset' : 'invitacion';
    $acceso = hippo_crm_acceso_por_token($tipo, $request->get_param('token'));
    if (!$acceso || get_post_meta($acceso->ID, 'estado', true) === 'DESACTIVADO') {
        return new WP_REST_Response(['error' => 'Link vencido o inválido'], 404);
    }
    $cliente = get_post((int) get_post_meta($acceso->ID, 'cliente_id', true));
    return new WP_REST_Response([
        'nombre'  => $acceso->post_title,
        'email'   => get_post_meta($acceso->ID, 'email', true),
        'cliente' => $cliente ? $cliente->post_title : null,
        'idioma'  => hippo_crm_idioma_cliente($cliente ? $cliente->ID : 0),
    ], 200);
}

// Crea la contraseña con el link de la invitación o de "olvidé mi contraseña" y deja la sesión iniciada
function hippo_crm_portal_definir_clave($request) {
    $params = $request->get_json_params() ?: [];
    $tipo = ($params['tipo'] ?? '') === 'reset' ? 'reset' : 'invitacion';
    $acceso = hippo_crm_acceso_por_token($tipo, $params['token'] ?? '');
    if (!$acceso || get_post_meta($acceso->ID, 'estado', true) === 'DESACTIVADO') {
        return new WP_REST_Response(['error' => 'Link vencido o inválido', 'codigo' => 'link_invalido'], 404);
    }
    $clave = $params['password'] ?? '';
    if (!hippo_crm_validar_clave($clave)) {
        return new WP_REST_Response(['error' => 'La contraseña es muy corta', 'codigo' => 'clave_corta'], 400);
    }

    update_post_meta($acceso->ID, 'clave_hash', wp_hash_password($clave));
    update_post_meta($acceso->ID, 'estado', 'ACTIVO');
    hippo_crm_borrar_token_acceso($acceso->ID, 'invitacion');
    hippo_crm_borrar_token_acceso($acceso->ID, 'reset');
    // Con contraseña nueva se cierran las sesiones abiertas
    hippo_crm_portal_borrar_sesiones($acceso->ID);
    delete_transient('hippo_crm_portal_fallos_' . md5(get_post_meta($acceso->ID, 'email', true)));
    return new WP_REST_Response(hippo_crm_respuesta_sesion($acceso), 200);
}

// Siempre responde lo mismo (no revela qué emails tienen acceso)
function hippo_crm_portal_olvide($request) {
    $params = $request->get_json_params() ?: [];
    $email = hippo_crm_normalizar_email($params['email'] ?? '');
    $acceso = $email !== '' ? hippo_crm_acceso_por_email($email) : null;
    if ($acceso && get_post_meta($acceso->ID, 'estado', true) === 'ACTIVO') {
        $llave = 'hippo_crm_portal_resets_' . md5($email);
        $pedidos = (int) get_transient($llave);
        if ($pedidos < HIPPO_CRM_PORTAL_MAX_RESETS_HORA) {
            set_transient($llave, $pedidos + 1, HOUR_IN_SECONDS);
            $token = hippo_crm_nuevo_token_acceso($acceso->ID, 'reset', HIPPO_CRM_PORTAL_RESET_SEG);
            hippo_crm_portal_email($acceso, 'reset', $token);
        }
    }
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_portal_salir($request) {
    $acceso = hippo_crm_portal_acceso_de($request);
    if ($acceso && preg_match('/^Bearer\s+([a-f0-9]{64})$/', (string) $request->get_header('authorization'), $m)) {
        hippo_crm_portal_borrar_sesion($acceso->ID, hippo_crm_hash_token($m[1]));
    }
    return new WP_REST_Response(['success' => true], 200);
}

// Estado de cuenta + propuestas (sin borradores) del cliente del acceso
function hippo_crm_portal_estado($request) {
    $acceso = hippo_crm_portal_acceso_de($request);
    if (!$acceso) return new WP_REST_Response(['error' => 'Sesión vencida'], 401);
    $cliente = get_post((int) get_post_meta($acceso->ID, 'cliente_id', true));
    if (!$cliente) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);

    $propuestas = get_posts(['post_type' => 'hippo_propuesta', 'numberposts' => -1, 'meta_key' => 'cliente_id', 'meta_value' => $cliente->ID]);
    $visibles = [];
    foreach ($propuestas as $p) {
        $datos = hippo_crm_propuesta_to_array($p);
        if ($datos['estado'] === 'BORRADOR') continue;
        $visibles[] = array_intersect_key($datos, array_flip([
            'id', 'tipo', 'titulo', 'estado', 'moneda', 'fecha', 'fechaVencimiento', 'descuento', 'items', 'token', 'respondidaEl',
        ])) + ['vencida' => hippo_crm_propuesta_vencida($p->ID)];
    }

    $respuesta = new WP_REST_Response(hippo_crm_estado_de_cliente($cliente) + [
        'propuestas' => $visibles,
        'acceso'     => ['nombre' => $acceso->post_title, 'email' => get_post_meta($acceso->ID, 'email', true)],
    ], 200);
    $respuesta->header('Cache-Control', 'no-store');
    return $respuesta;
}
