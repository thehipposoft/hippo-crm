<?php
// Hippo CRM — Rutas REST y login

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    register_rest_route('hippo/v1', '/login', [
        'methods' => 'POST', 'callback' => 'hippo_crm_login', 'permission_callback' => '__return_true',
    ]);

    // Clientes
    register_rest_route('hippo/v1', '/clientes', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_clientes',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_cliente', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/clientes/(?P<id>\d+)', [
        ['methods' => 'GET', 'callback' => 'hippo_crm_get_cliente',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT', 'callback' => 'hippo_crm_update_cliente', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/clientes/(?P<id>\d+)/link-publico', [
        ['methods' => 'POST',   'callback' => 'hippo_crm_generar_link_publico', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_revocar_link_publico', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    // Sin login: lo abre el cliente con su link. El token (64 hex) es la única credencial.
    register_rest_route('hippo/v1', '/publico/estado-de-cuenta/(?P<token>[a-f0-9]{64})', [
        'methods' => 'GET', 'callback' => 'hippo_crm_estado_publico', 'permission_callback' => '__return_true',
    ]);
    register_rest_route('hippo/v1', '/clientes/(?P<id>\d+)/proyectos', [
        'methods' => 'GET', 'callback' => 'hippo_crm_get_proyectos_by_cliente', 'permission_callback' => 'hippo_crm_check_token',
    ]);

    // Proyectos
    register_rest_route('hippo/v1', '/proyectos', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_proyectos',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_proyecto', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/proyectos/(?P<id>\d+)', [
        ['methods' => 'GET', 'callback' => 'hippo_crm_get_proyecto',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT', 'callback' => 'hippo_crm_update_proyecto', 'permission_callback' => 'hippo_crm_check_token'],
    ]);

    // Pagos
    register_rest_route('hippo/v1', '/pagos', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_pagos',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_pago', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/pagos/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_pago',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_pago', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_pago', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/proyectos/(?P<id>\d+)/pagos', [
        'methods' => 'GET', 'callback' => 'hippo_crm_get_pagos_by_proyecto', 'permission_callback' => 'hippo_crm_check_token',
    ]);

    // Tareas y usuarios del equipo
    register_rest_route('hippo/v1', '/tareas', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_tareas',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_tarea', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/tareas/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_tarea',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_tarea', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_tarea', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/usuarios', [
        'methods' => 'GET', 'callback' => 'hippo_crm_get_usuarios', 'permission_callback' => 'hippo_crm_check_token',
    ]);

    // Unidades (casillas, licencias, etc.)
    register_rest_route('hippo/v1', '/unidades', [
        'methods' => 'POST', 'callback' => 'hippo_crm_create_unidad', 'permission_callback' => 'hippo_crm_check_token',
    ]);
    register_rest_route('hippo/v1', '/unidades/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_unidad',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_unidad', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_unidad', 'permission_callback' => 'hippo_crm_check_token'],
    ]);

    // Costos
    register_rest_route('hippo/v1', '/costos', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_costos',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_costo', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/costos/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_costo',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_costo', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_costo', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    // Archivos de proyectos: subida y descarga directas con ticket (ver archivos.php)
    register_rest_route('hippo/v1', '/proyectos/(?P<id>\d+)/archivos/ticket', [
        'methods' => 'POST', 'callback' => 'hippo_crm_ticket_subida', 'permission_callback' => 'hippo_crm_check_token',
    ]);
    register_rest_route('hippo/v1', '/subir/(?P<ticket>[a-f0-9]{48})', [
        'methods' => 'POST', 'callback' => 'hippo_crm_subir_archivo', 'permission_callback' => '__return_true',
    ]);
    register_rest_route('hippo/v1', '/archivos/(?P<id>\d+)', [
        'methods' => 'DELETE', 'callback' => 'hippo_crm_delete_archivo', 'permission_callback' => 'hippo_crm_check_token',
    ]);
    register_rest_route('hippo/v1', '/archivos/(?P<id>\d+)/ticket', [
        'methods' => 'POST', 'callback' => 'hippo_crm_ticket_descarga', 'permission_callback' => 'hippo_crm_check_token',
    ]);
    register_rest_route('hippo/v1', '/descargar/(?P<ticket>[a-f0-9]{48})', [
        'methods' => 'GET', 'callback' => 'hippo_crm_descargar_archivo', 'permission_callback' => '__return_true',
    ]);

    // Portal de clientes: accesos (con login del equipo) y portal (con su propia sesión)
    register_rest_route('hippo/v1', '/clientes/(?P<id>\d+)/accesos', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_accesos',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_invitar_acceso', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/accesos/(?P<id>\d+)', [
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_acceso', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_acceso', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/accesos/(?P<id>\d+)/invitacion', [
        'methods' => 'POST', 'callback' => 'hippo_crm_reenviar_invitacion', 'permission_callback' => 'hippo_crm_check_token',
    ]);
    foreach ([
        ['/portal/login', 'POST', 'hippo_crm_portal_login'],
        ['/portal/token', 'GET', 'hippo_crm_portal_ver_token'],
        ['/portal/clave', 'POST', 'hippo_crm_portal_definir_clave'],
        ['/portal/olvide', 'POST', 'hippo_crm_portal_olvide'],
        ['/portal/salir', 'POST', 'hippo_crm_portal_salir'],
    ] as [$ruta, $metodo, $callback]) {
        register_rest_route('hippo/v1', $ruta, ['methods' => $metodo, 'callback' => $callback, 'permission_callback' => '__return_true']);
    }
    register_rest_route('hippo/v1', '/portal/estado', [
        'methods' => 'GET', 'callback' => 'hippo_crm_portal_estado', 'permission_callback' => 'hippo_crm_portal_check',
    ]);

    // Propuestas y cotizaciones
    register_rest_route('hippo/v1', '/propuestas', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_propuestas',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_propuesta', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/propuestas/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_propuesta',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_propuesta', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_propuesta', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    // Sin login: el cliente la ve y la acepta o rechaza con su link. El token (64 hex) es la única credencial.
    register_rest_route('hippo/v1', '/publico/propuesta/(?P<token>[a-f0-9]{64})', [
        'methods' => 'GET', 'callback' => 'hippo_crm_propuesta_publica', 'permission_callback' => '__return_true',
    ]);
    register_rest_route('hippo/v1', '/publico/propuesta/(?P<token>[a-f0-9]{64})/respuesta', [
        'methods' => 'POST', 'callback' => 'hippo_crm_responder_propuesta', 'permission_callback' => '__return_true',
    ]);
    register_rest_route('hippo/v1', '/plantillas', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_plantillas',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_plantilla', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/plantillas/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_plantilla',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_plantilla', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_plantilla', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/cuentas-bancarias', [
        ['methods' => 'GET',  'callback' => 'hippo_crm_get_cuentas',   'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'POST', 'callback' => 'hippo_crm_create_cuenta', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
    register_rest_route('hippo/v1', '/cuentas-bancarias/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_cuenta',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_cuenta', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_cuenta', 'permission_callback' => 'hippo_crm_check_token'],
    ]);

    // Pagos de costos
    register_rest_route('hippo/v1', '/pagos-costo', [
        'methods' => 'POST', 'callback' => 'hippo_crm_create_pago_costo', 'permission_callback' => 'hippo_crm_check_token',
    ]);
    register_rest_route('hippo/v1', '/pagos-costo/(?P<id>\d+)', [
        ['methods' => 'GET',    'callback' => 'hippo_crm_get_pago_costo',    'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'PUT',    'callback' => 'hippo_crm_update_pago_costo', 'permission_callback' => 'hippo_crm_check_token'],
        ['methods' => 'DELETE', 'callback' => 'hippo_crm_delete_pago_costo', 'permission_callback' => 'hippo_crm_check_token'],
    ]);
});

// Valida la Application Password directo (antes hacía un request HTTP a sí mismo, que algunos
// hostings bloquean y terminaba en "credenciales inválidas" aunque estuvieran bien).
// `codigo` le dice al CRM qué mostrar.
function hippo_crm_login($request) {
    $username = sanitize_text_field((string) $request->get_param('username'));
    $app_password = (string) $request->get_param('password');
    if ($username === '' || $app_password === '') {
        return new WP_REST_Response(['error' => 'Faltan usuario o contraseña', 'codigo' => 'credenciales'], 401);
    }
    // Se habilitan solo para esta validación aunque un plugin de seguridad las desactive (ver app-passwords.php)
    hippo_crm_forzar_app_passwords(true);
    $user = wp_authenticate_application_password(null, $username, $app_password);
    hippo_crm_forzar_app_passwords(false);
    if (!($user instanceof WP_User)) {
        // ¿Puso la contraseña normal de WordPress? No se acepta, pero se le explica
        $campo = is_email($username) ? 'email' : 'login';
        $candidato = get_user_by($campo, $username);
        $es_normal = $candidato && wp_check_password($app_password, $candidato->user_pass, $candidato->ID);
        return new WP_REST_Response([
            'error'  => 'Credenciales inválidas',
            'codigo' => $es_normal ? 'password_normal' : 'credenciales',
        ], 401);
    }

    $token = bin2hex(random_bytes(32));
    update_user_meta($user->ID, 'hippo_crm_token', $token);
    update_user_meta($user->ID, 'hippo_crm_token_expires', time() + 7 * DAY_IN_SECONDS);

    return new WP_REST_Response([
        'token' => $token,
        'user'  => ['name' => $user->display_name],
    ], 200);
}

function hippo_crm_check_token($request) {
    $auth = $request->get_header('authorization');
    if (!$auth || !preg_match('/Bearer\s+(.+)/', $auth, $m)) return false;

    $users = get_users(['meta_key' => 'hippo_crm_token', 'meta_value' => $m[1], 'number' => 1]);
    if (empty($users)) return false;

    $expires = get_user_meta($users[0]->ID, 'hippo_crm_token_expires', true);
    return $expires && time() <= $expires;
}
