<?php
// Hippo CRM — Meta boxes para editar desde el admin

if (!defined('ABSPATH')) exit;

add_action('add_meta_boxes', function () {
    add_meta_box('hippo_cliente_datos', 'Datos del cliente', 'hippo_cliente_metabox_html', 'hippo_cliente', 'normal', 'high');
    add_meta_box('hippo_proyecto_datos', 'Datos del proyecto', 'hippo_proyecto_metabox_html', 'hippo_proyecto', 'normal', 'high');
    add_meta_box('hippo_pago_datos', 'Datos del pago', 'hippo_pago_metabox_html', 'hippo_pago', 'normal', 'high');
    add_meta_box('hippo_costo_datos', 'Datos del costo', 'hippo_costo_metabox_html', 'hippo_costo', 'normal', 'high');
});

function hippo_cliente_metabox_html($post) {
    wp_nonce_field('hippo_cliente_save', 'hippo_cliente_nonce');
    $contacto = get_post_meta($post->ID, 'contacto', true);
    $telefono = get_post_meta($post->ID, 'telefono', true);
    $email_contacto = get_post_meta($post->ID, 'email_contacto', true);
    $pais = get_post_meta($post->ID, 'pais', true);
    ?>
    <p><label>Contacto (nombre de la persona)<br><input type="text" name="contacto" value="<?php echo esc_attr($contacto); ?>" class="widefat"></label></p>
    <p><label>Teléfono<br><input type="tel" name="telefono" value="<?php echo esc_attr($telefono); ?>" class="widefat" placeholder="Opcional"></label></p>
    <p><label>Email de contacto<br><input type="email" name="email_contacto" value="<?php echo esc_attr($email_contacto); ?>" class="widefat"></label></p>
    <p><label>País<br><input type="text" name="pais" value="<?php echo esc_attr($pais); ?>" class="widefat" placeholder="Ej: Argentina"></label></p>
    <?php
}

add_action('save_post_hippo_cliente', function ($post_id) {
    if (!isset($_POST['hippo_cliente_nonce']) || !wp_verify_nonce($_POST['hippo_cliente_nonce'], 'hippo_cliente_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['contacto'])) update_post_meta($post_id, 'contacto', sanitize_text_field($_POST['contacto']));
    if (isset($_POST['telefono'])) update_post_meta($post_id, 'telefono', sanitize_text_field($_POST['telefono']));
    if (isset($_POST['email_contacto'])) update_post_meta($post_id, 'email_contacto', sanitize_email($_POST['email_contacto']));
    if (isset($_POST['pais'])) update_post_meta($post_id, 'pais', sanitize_text_field($_POST['pais']));
});

function hippo_proyecto_metabox_html($post) {
    wp_nonce_field('hippo_proyecto_save', 'hippo_proyecto_nonce');
    $cliente_id = get_post_meta($post->ID, 'cliente_id', true);
    $estado = get_post_meta($post->ID, 'estado', true) ?: 'PROSPECTO';
    $fecha_inicio = get_post_meta($post->ID, 'fecha_inicio', true);
    $deadline = get_post_meta($post->ID, 'deadline', true);
    $accion_pendiente = get_post_meta($post->ID, 'accion_pendiente', true);
    $tipo_proyecto = get_post_meta($post->ID, 'tipo_proyecto', true) ?: 'ON_OFF';
    $valor = get_post_meta($post->ID, 'valor', true);
    $moneda = get_post_meta($post->ID, 'moneda', true) ?: 'USD';
    $frecuencia_pago = get_post_meta($post->ID, 'frecuencia_pago', true) ?: 'MENSUAL';
    $url = get_post_meta($post->ID, 'url', true);
    $estados = ['PROSPECTO', 'EN_NEGOCIACION', 'ACTIVO', 'EN_PAUSA', 'CERRADO', 'PERDIDO'];
    $frecuencias = ['SEMANAL' => 'Semanal', 'MENSUAL' => 'Mensual', 'ANUAL' => 'Anual'];
    $clientes = get_posts(['post_type' => 'hippo_cliente', 'numberposts' => -1]);
    ?>
    <p><label>Cliente<br>
        <select name="cliente_id" class="widefat" required>
            <option value="">— Seleccionar —</option>
            <?php foreach ($clientes as $c): ?>
                <option value="<?php echo $c->ID; ?>" <?php selected($cliente_id, $c->ID); ?>><?php echo esc_html($c->post_title); ?></option>
            <?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Estado<br>
        <select name="estado" class="widefat">
            <?php foreach ($estados as $e): ?><option value="<?php echo $e; ?>" <?php selected($estado, $e); ?>><?php echo $e; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Fecha de inicio<br><input type="date" name="fecha_inicio" value="<?php echo esc_attr($fecha_inicio); ?>"></label></p>
    <p><label>Deadline<br><input type="date" name="deadline" value="<?php echo esc_attr($deadline); ?>"></label></p>

    <p><label>Tipo de proyecto<br>
        <select name="tipo_proyecto" id="hippo_tipo_proyecto" class="widefat">
            <option value="ON_OFF" <?php selected($tipo_proyecto, 'ON_OFF'); ?>>On-off (pago único)</option>
            <option value="RECURRENTE" <?php selected($tipo_proyecto, 'RECURRENTE'); ?>>Recurrente</option>
        </select>
    </label></p>
    <p><label>Valor<br><input type="number" step="0.01" name="valor" value="<?php echo esc_attr($valor); ?>" class="widefat"></label></p>
    <p><label>Moneda<br>
        <select name="moneda" class="widefat">
            <?php foreach (HIPPO_CRM_MONEDAS as $m): ?><option value="<?php echo $m; ?>" <?php selected($moneda, $m); ?>><?php echo $m; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <p id="hippo_frecuencia_wrap" style="<?php echo $tipo_proyecto === 'RECURRENTE' ? '' : 'display:none;'; ?>">
        <label>Frecuencia de pago<br>
            <select name="frecuencia_pago" class="widefat">
                <?php foreach ($frecuencias as $val => $label): ?>
                    <option value="<?php echo $val; ?>" <?php selected($frecuencia_pago, $val); ?>><?php echo $label; ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </p>
    <p><label>URL<br><input type="url" name="url" value="<?php echo esc_attr($url); ?>" class="widefat" placeholder="https://..."></label></p>

    <p><label>Acción pendiente<br><textarea name="accion_pendiente" class="widefat"><?php echo esc_textarea($accion_pendiente); ?></textarea></label></p>

    <script>
    (function () {
        var tipo = document.getElementById('hippo_tipo_proyecto');
        var wrap = document.getElementById('hippo_frecuencia_wrap');
        if (!tipo || !wrap) return;
        tipo.addEventListener('change', function () {
            wrap.style.display = tipo.value === 'RECURRENTE' ? '' : 'none';
        });
    })();
    </script>
    <?php
}

add_action('save_post_hippo_proyecto', function ($post_id) {
    if (!isset($_POST['hippo_proyecto_nonce']) || !wp_verify_nonce($_POST['hippo_proyecto_nonce'], 'hippo_proyecto_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['cliente_id'])) update_post_meta($post_id, 'cliente_id', (int) $_POST['cliente_id']);
    foreach (['estado', 'fecha_inicio', 'deadline', 'tipo_proyecto', 'valor', 'frecuencia_pago'] as $field) {
        if (isset($_POST[$field])) update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
    }
    if (isset($_POST['moneda']) && in_array($_POST['moneda'], HIPPO_CRM_MONEDAS, true)) {
        update_post_meta($post_id, 'moneda', $_POST['moneda']);
    }
    if (isset($_POST['url'])) update_post_meta($post_id, 'url', esc_url_raw($_POST['url']));
    if (isset($_POST['accion_pendiente'])) update_post_meta($post_id, 'accion_pendiente', sanitize_textarea_field($_POST['accion_pendiente']));
});

function hippo_pago_metabox_html($post) {
    wp_nonce_field('hippo_pago_save', 'hippo_pago_nonce');
    $proyecto_id = get_post_meta($post->ID, 'proyecto_id', true);
    $fecha = get_post_meta($post->ID, 'fecha', true);
    $monto = get_post_meta($post->ID, 'monto', true);
    $moneda = get_post_meta($post->ID, 'moneda', true) ?: 'USD';
    $medio_pago = get_post_meta($post->ID, 'medio_pago', true);
    $notas = get_post_meta($post->ID, 'notas', true);
    $medios = ['Transferencia', 'Efectivo', 'Tarjeta', 'Cheque', 'Otro'];
    $proyectos = get_posts(['post_type' => 'hippo_proyecto', 'numberposts' => -1]);
    ?>
    <p><label>Proyecto<br>
        <select name="proyecto_id" class="widefat" required>
            <option value="">— Seleccionar —</option>
            <?php foreach ($proyectos as $p):
                $cliente_id = get_post_meta($p->ID, 'cliente_id', true);
                $cliente = get_post($cliente_id);
                $label = $p->post_title . ($cliente ? ' — ' . $cliente->post_title : '');
            ?>
                <option value="<?php echo $p->ID; ?>" <?php selected($proyecto_id, $p->ID); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Fecha<br><input type="date" name="fecha" value="<?php echo esc_attr($fecha); ?>"></label></p>
    <p><label>Monto<br><input type="number" step="0.01" name="monto" value="<?php echo esc_attr($monto); ?>" class="widefat"></label></p>
    <p><label>Moneda<br>
        <select name="moneda" class="widefat">
            <?php foreach (HIPPO_CRM_MONEDAS as $m): ?><option value="<?php echo $m; ?>" <?php selected($moneda, $m); ?>><?php echo $m; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Medio de pago<br>
        <select name="medio_pago" class="widefat">
            <?php foreach ($medios as $m): ?><option value="<?php echo $m; ?>" <?php selected($medio_pago, $m); ?>><?php echo $m; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Notas adicionales<br><textarea name="notas" class="widefat"><?php echo esc_textarea($notas); ?></textarea></label></p>
    <?php
}

add_action('save_post_hippo_pago', function ($post_id) {
    if (!isset($_POST['hippo_pago_nonce']) || !wp_verify_nonce($_POST['hippo_pago_nonce'], 'hippo_pago_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['proyecto_id'])) update_post_meta($post_id, 'proyecto_id', (int) $_POST['proyecto_id']);
    foreach (['fecha', 'monto', 'moneda', 'medio_pago'] as $field) {
        if (isset($_POST[$field])) update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
    }
    if (isset($_POST['notas'])) update_post_meta($post_id, 'notas', sanitize_textarea_field($_POST['notas']));
});

function hippo_costo_metabox_html($post) {
    wp_nonce_field('hippo_costo_save', 'hippo_costo_nonce');
    $monto = get_post_meta($post->ID, 'monto', true);
    $moneda = get_post_meta($post->ID, 'moneda', true) ?: 'USD';
    $metodo_pago = get_post_meta($post->ID, 'metodo_pago', true);
    $frecuencia = get_post_meta($post->ID, 'frecuencia', true) ?: 'MENSUAL';
    $fecha_renovacion = get_post_meta($post->ID, 'fecha_renovacion', true);
    $fecha_inicio = get_post_meta($post->ID, 'fecha_inicio', true);
    $fecha_baja = get_post_meta($post->ID, 'fecha_baja', true);
    $metodos = ['Transferencia', 'Efectivo', 'Tarjeta', 'Cheque', 'Otro'];
    $frecuencias = ['SEMANAL' => 'Semanal', 'MENSUAL' => 'Mensual', 'ANUAL' => 'Anual'];
    ?>
    <p><label>Monto<br><input type="number" step="0.01" name="monto" value="<?php echo esc_attr($monto); ?>" class="widefat"></label></p>
    <p><label>Moneda<br>
        <select name="moneda" class="widefat">
            <?php foreach (HIPPO_CRM_MONEDAS as $m): ?><option value="<?php echo $m; ?>" <?php selected($moneda, $m); ?>><?php echo $m; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Método de pago<br>
        <select name="metodo_pago" class="widefat">
            <?php foreach ($metodos as $m): ?><option value="<?php echo $m; ?>" <?php selected($metodo_pago, $m); ?>><?php echo $m; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Frecuencia<br>
        <select name="frecuencia" class="widefat">
            <?php foreach ($frecuencias as $val => $label): ?>
                <option value="<?php echo $val; ?>" <?php selected($frecuencia, $val); ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
        </select>
    </label></p>
    <p><label>Fecha de renovación<br><input type="date" name="fecha_renovacion" value="<?php echo esc_attr($fecha_renovacion); ?>"></label></p>
    <p><label>Fecha de alta<br><input type="date" name="fecha_inicio" value="<?php echo esc_attr($fecha_inicio); ?>"></label></p>
    <p><label>Fecha de baja (vacío = sigue activo)<br><input type="date" name="fecha_baja" value="<?php echo esc_attr($fecha_baja); ?>"></label></p>
    <p><label>Categoría<br>
        <select name="categoria" class="widefat">
            <option value="">—</option>
            <?php foreach (HIPPO_CRM_COSTO_CATEGORIAS as $c): ?><option value="<?php echo $c; ?>" <?php selected(get_post_meta($post->ID, 'categoria', true), $c); ?>><?php echo $c; ?></option><?php endforeach; ?>
        </select>
    </label></p>
    <?php
}

add_action('save_post_hippo_costo', function ($post_id) {
    if (!isset($_POST['hippo_costo_nonce']) || !wp_verify_nonce($_POST['hippo_costo_nonce'], 'hippo_costo_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    foreach (['monto', 'moneda', 'metodo_pago', 'frecuencia', 'fecha_renovacion', 'fecha_inicio', 'fecha_baja', 'categoria'] as $field) {
        if (isset($_POST[$field])) update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
    }
});
