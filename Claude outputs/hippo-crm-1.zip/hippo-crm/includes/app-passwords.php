<?php
// Hippo CRM — Contraseñas de aplicación

if (!defined('ABSPATH')) exit;

// Algunos plugins de seguridad (Wordfence, Hostinger Tools, etc.) desactivan las contraseñas de
// aplicación para todo el sitio. El CRM las necesita solo en dos lugares, y se habilitan solo ahí:
//   1. El login del CRM (hippo_crm_login), que después usa su propio token.
//   2. La pantalla de perfil de wp-admin, para poder crearlas y revocarlas.
// El resto de la API de WordPress sigue como lo dejó el plugin de seguridad.

const HIPPO_CRM_PRIORIDAD_FORZAR = PHP_INT_MAX;

function hippo_crm_forzar_app_passwords($activar) {
    $filtros = ['wp_is_application_passwords_available', 'wp_is_application_passwords_available_for_user'];
    foreach ($filtros as $filtro) {
        if ($activar) add_filter($filtro, '__return_true', HIPPO_CRM_PRIORIDAD_FORZAR);
        else remove_filter($filtro, '__return_true', HIPPO_CRM_PRIORIDAD_FORZAR);
    }
}

// Perfil y edición de usuario en wp-admin: muestra la sección "Contraseñas de aplicación"
add_action('load-profile.php', fn() => hippo_crm_forzar_app_passwords(true));
add_action('load-user-edit.php', fn() => hippo_crm_forzar_app_passwords(true));

// La sección del perfil crea y revoca con la API (con la sesión de wp-admin)
add_filter('rest_pre_dispatch', function ($resultado, $server, $request) {
    if (preg_match('#^/wp/v2/users/(me|\d+)/application-passwords#', $request->get_route()) && is_user_logged_in()) {
        hippo_crm_forzar_app_passwords(true);
    }
    return $resultado;
}, 10, 3);
