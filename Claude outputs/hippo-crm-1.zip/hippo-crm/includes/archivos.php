<?php
// Hippo CRM — Archivos de proyectos (ej. la propuesta en PDF hecha fuera del CRM)

if (!defined('ABSPATH')) exit;

// Los archivos NO van a la biblioteca de medios: se guardan en una carpeta privada
// (wp-content/uploads/hippo-crm-privado, con .htaccess que bloquea el acceso directo)
// y se descargan solo con un ticket de pocos minutos que pide el CRM con sesión.
// La subida va directo del navegador a WordPress (también con ticket) para no pasar
// por Netlify, que corta los requests de más de ~6 MB.

const HIPPO_CRM_ARCHIVO_TIPOS = ['PROPUESTA', 'CONTRATO', 'OTRO'];
const HIPPO_CRM_ARCHIVO_EXTENSIONES = [
    'pdf'  => 'application/pdf',
    'doc'  => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'ppt'  => 'application/vnd.ms-powerpoint',
    'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'key'  => 'application/x-iwork-keynote-sffkey',
    'png'  => 'image/png',
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
];
const HIPPO_CRM_ARCHIVO_MAX_MB = 25;
const HIPPO_CRM_TICKET_SUBIDA_SEG   = 15 * MINUTE_IN_SECONDS;
const HIPPO_CRM_TICKET_DESCARGA_SEG = 5 * MINUTE_IN_SECONDS;

function hippo_crm_carpeta_privada() {
    $dir = trailingslashit(wp_upload_dir()['basedir']) . 'hippo-crm-privado';
    if (!is_dir($dir)) {
        wp_mkdir_p($dir);
        file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
        file_put_contents($dir . '/index.php', "<?php // Silencio\n");
    }
    return $dir;
}

function hippo_crm_archivo_to_array($post) {
    return [
        'id'       => $post->ID,
        'nombre'   => $post->post_title,
        'tipo'     => get_post_meta($post->ID, 'tipo', true) ?: 'OTRO',
        'mime'     => get_post_meta($post->ID, 'mime', true) ?: null,
        'tamano'   => (int) get_post_meta($post->ID, 'tamano', true),
        'subidoEl' => get_post_meta($post->ID, 'subido_el', true) ?: null,
    ];
}

function hippo_crm_archivos_de($proyecto_id) {
    $posts = get_posts([
        'post_type' => 'hippo_archivo', 'numberposts' => -1,
        'meta_key' => 'proyecto_id', 'meta_value' => (int) $proyecto_id,
        'orderby' => 'date', 'order' => 'DESC',
    ]);
    return array_map('hippo_crm_archivo_to_array', $posts);
}

function hippo_crm_nuevo_ticket($prefijo, $datos, $segundos) {
    $ticket = bin2hex(random_bytes(24));
    set_transient($prefijo . $ticket, $datos, $segundos);
    return $ticket;
}

// Devuelve los datos del ticket. La subida es de un solo uso; la descarga vale hasta que vence
// (el visor de PDF del navegador a veces vuelve a pedir el archivo).
function hippo_crm_usar_ticket($prefijo, $ticket, $un_solo_uso = true) {
    if (!preg_match('/^[a-f0-9]{48}$/', (string) $ticket)) return null;
    $datos = get_transient($prefijo . $ticket);
    if ($datos === false) return null;
    if ($un_solo_uso) delete_transient($prefijo . $ticket);
    return $datos;
}

// ==== Subida ====

// Con sesión: el CRM pide permiso para subir un archivo a un proyecto
function hippo_crm_ticket_subida($request) {
    $proyecto = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_proyecto');
    if (!$proyecto) return new WP_REST_Response(['error' => 'Proyecto no encontrado'], 404);
    $params = $request->get_json_params() ?: [];
    $tipo = $params['tipo'] ?? 'PROPUESTA';
    if (!in_array($tipo, HIPPO_CRM_ARCHIVO_TIPOS, true)) return new WP_REST_Response(['error' => 'Tipo inválido'], 400);

    $ticket = hippo_crm_nuevo_ticket('hippo_crm_subida_', ['proyecto_id' => $proyecto->ID, 'tipo' => $tipo], HIPPO_CRM_TICKET_SUBIDA_SEG);
    return new WP_REST_Response([
        'url'    => rest_url('hippo/v1/subir/' . $ticket),
        'maxMb'  => HIPPO_CRM_ARCHIVO_MAX_MB,
    ], 201);
}

// Sin login: el navegador sube el archivo con el ticket (campo multipart "archivo")
function hippo_crm_subir_archivo($request) {
    $datos = hippo_crm_usar_ticket('hippo_crm_subida_', $request->get_param('ticket'));
    if (!$datos) return new WP_REST_Response(['error' => 'El permiso para subir venció. Probá de nuevo.'], 403);

    $archivos = $request->get_file_params();
    $archivo = $archivos['archivo'] ?? null;
    if (!$archivo || !empty($archivo['error']) || !is_uploaded_file($archivo['tmp_name'])) {
        return new WP_REST_Response(['error' => 'No llegó el archivo.'], 400);
    }
    if ($archivo['size'] > HIPPO_CRM_ARCHIVO_MAX_MB * MB_IN_BYTES) {
        return new WP_REST_Response(['error' => 'El archivo supera los ' . HIPPO_CRM_ARCHIVO_MAX_MB . ' MB.'], 413);
    }

    // La extensión manda; se confirma el tipo real del contenido
    $nombre = sanitize_file_name($archivo['name']);
    $extension = strtolower(pathinfo($nombre, PATHINFO_EXTENSION));
    if (!isset(HIPPO_CRM_ARCHIVO_EXTENSIONES[$extension])) {
        return new WP_REST_Response(['error' => 'Tipo de archivo no permitido (PDF, Word, PowerPoint, Keynote o imagen).'], 415);
    }
    $chequeo = wp_check_filetype_and_ext($archivo['tmp_name'], $nombre, HIPPO_CRM_ARCHIVO_EXTENSIONES);
    if ($extension !== 'key' && empty($chequeo['ext'])) {
        return new WP_REST_Response(['error' => 'El contenido no coincide con la extensión del archivo.'], 415);
    }

    // Nombre en disco aleatorio: el original solo queda en la base
    $ruta = hippo_crm_carpeta_privada() . '/' . bin2hex(random_bytes(16)) . '.' . $extension;
    if (!move_uploaded_file($archivo['tmp_name'], $ruta)) {
        return new WP_REST_Response(['error' => 'No se pudo guardar el archivo.'], 500);
    }

    $id = wp_insert_post([
        'post_type' => 'hippo_archivo', 'post_title' => $nombre, 'post_status' => 'publish',
    ]);
    update_post_meta($id, 'proyecto_id', (int) $datos['proyecto_id']);
    update_post_meta($id, 'tipo', $datos['tipo']);
    update_post_meta($id, 'mime', HIPPO_CRM_ARCHIVO_EXTENSIONES[$extension]);
    update_post_meta($id, 'tamano', (int) $archivo['size']);
    update_post_meta($id, 'ruta', basename($ruta));
    update_post_meta($id, 'subido_el', hippo_crm_ahora_utc());

    return new WP_REST_Response(hippo_crm_archivo_to_array(get_post($id)), 201);
}

// ==== Descarga ====

function hippo_crm_ticket_descarga($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_archivo');
    if (!$post) return new WP_REST_Response(['error' => 'Archivo no encontrado'], 404);
    $ticket = hippo_crm_nuevo_ticket('hippo_crm_descarga_', ['archivo_id' => $post->ID], HIPPO_CRM_TICKET_DESCARGA_SEG);
    return new WP_REST_Response(['url' => rest_url('hippo/v1/descargar/' . $ticket)], 201);
}

// Sin login: el navegador abre la URL con el ticket y recibe el archivo
function hippo_crm_descargar_archivo($request) {
    $datos = hippo_crm_usar_ticket('hippo_crm_descarga_', $request->get_param('ticket'), false);
    $post = $datos ? hippo_crm_get_post_of_type($datos['archivo_id'], 'hippo_archivo') : null;
    if (!$post) return new WP_REST_Response(['error' => 'El link de descarga venció. Volvé al CRM y probá de nuevo.'], 403);

    $ruta = hippo_crm_carpeta_privada() . '/' . basename((string) get_post_meta($post->ID, 'ruta', true));
    if (!is_file($ruta)) return new WP_REST_Response(['error' => 'El archivo ya no existe'], 404);

    $mime = get_post_meta($post->ID, 'mime', true) ?: 'application/octet-stream';
    // PDF e imágenes se abren en el navegador; el resto se descarga
    $disposicion = ($mime === 'application/pdf' || str_starts_with($mime, 'image/')) ? 'inline' : 'attachment';
    $nombre = str_replace(['"', "\r", "\n"], '', $post->post_title);

    nocache_headers();
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($ruta));
    header('Content-Disposition: ' . $disposicion . '; filename="' . $nombre . '"; filename*=UTF-8\'\'' . rawurlencode($nombre));
    header('X-Content-Type-Options: nosniff');
    readfile($ruta);
    exit;
}

function hippo_crm_delete_archivo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_archivo');
    if (!$post) return new WP_REST_Response(['error' => 'Archivo no encontrado'], 404);
    $ruta = hippo_crm_carpeta_privada() . '/' . basename((string) get_post_meta($post->ID, 'ruta', true));
    if (is_file($ruta)) unlink($ruta);
    wp_delete_post($post->ID, true);
    return new WP_REST_Response(['success' => true], 200);
}
