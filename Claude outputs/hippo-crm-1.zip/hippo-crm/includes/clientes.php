<?php
// Hippo CRM — Clientes

if (!defined('ABSPATH')) exit;

function hippo_crm_cliente_to_array($post) {
    return [
        'id'            => $post->ID,
        'nombre'        => $post->post_title,
        'contacto'      => get_post_meta($post->ID, 'contacto', true),
        'telefono'      => get_post_meta($post->ID, 'telefono', true),
        'emailContacto' => get_post_meta($post->ID, 'email_contacto', true),
        'pais'          => get_post_meta($post->ID, 'pais', true),
        // Solo sale por endpoints con login (el CRM arma el link con esto)
        'tokenPublico'  => get_post_meta($post->ID, 'token_publico', true) ?: null,
    ];
}

function hippo_crm_get_clientes() {
    $posts = get_posts(['post_type' => 'hippo_cliente', 'numberposts' => -1]);
    return new WP_REST_Response(array_map('hippo_crm_cliente_to_array', $posts), 200);
}

function hippo_crm_get_cliente($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cliente');
    if (!$post) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);
    return new WP_REST_Response(hippo_crm_cliente_to_array($post), 200);
}

function hippo_crm_save_cliente_meta($id, $params) {
    hippo_crm_save_meta($id, $params, HIPPO_CRM_CLIENTE_CAMPOS);
    hippo_crm_save_meta($id, $params, ['email_contacto'], 'sanitize_email');
}

function hippo_crm_create_cliente($request) {
    $params = $request->get_json_params();
    if (empty($params['nombre'])) return new WP_REST_Response(['error' => 'nombre es obligatorio'], 400);

    $id = wp_insert_post(['post_type' => 'hippo_cliente', 'post_title' => sanitize_text_field($params['nombre']), 'post_status' => 'publish']);
    hippo_crm_save_cliente_meta($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_cliente($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cliente');
    if (!$post) return new WP_REST_Response(['error' => 'Cliente no encontrado'], 404);

    $params = $request->get_json_params();
    if (!empty($params['nombre'])) wp_update_post(['ID' => $post->ID, 'post_title' => sanitize_text_field($params['nombre'])]);
    hippo_crm_save_cliente_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}
