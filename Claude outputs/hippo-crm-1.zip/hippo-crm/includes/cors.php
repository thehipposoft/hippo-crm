<?php
// Hippo CRM — CORS

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
    add_filter('rest_pre_serve_request', function ($value) {
        $allowed = ['https://crm.thehipposoft.com', 'https://thehipposoft.com', 'https://www.thehipposoft.com', 'https://wp.thehipposoft.com', 'http://localhost:3000'];
        $origin = get_http_origin();
        if ($origin && in_array($origin, $allowed)) header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type');
        return $value;
    });
}, 15);
