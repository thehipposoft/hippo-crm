<?php
// Hippo CRM — Costos

if (!defined('ABSPATH')) exit;

function hippo_crm_costo_to_array($post) {
    return [
        'id'              => $post->ID,
        'nombreCosto'     => $post->post_title,
        'monto'           => (float) get_post_meta($post->ID, 'monto', true),
        'moneda'          => get_post_meta($post->ID, 'moneda', true) ?: 'USD',
        'metodoPago'      => get_post_meta($post->ID, 'metodo_pago', true) ?: null,
        'frecuencia'      => get_post_meta($post->ID, 'frecuencia', true) ?: 'MENSUAL',
        'fechaRenovacion' => get_post_meta($post->ID, 'fecha_renovacion', true) ?: null,
        // Vigencia: el CRM solo suma el costo en los meses entre alta y baja
        'fechaInicio'     => get_post_meta($post->ID, 'fecha_inicio', true) ?: null,
        'fechaBaja'       => get_post_meta($post->ID, 'fecha_baja', true) ?: null,
        'categoria'       => get_post_meta($post->ID, 'categoria', true) ?: null,
        // Los pagos viajan con el costo: el CRM calcula qué períodos están pagados
        'pagos'           => hippo_crm_pagos_de_costo($post->ID),
    ];
}

function hippo_crm_get_costos() {
    $posts = get_posts(['post_type' => 'hippo_costo', 'numberposts' => -1]);
    return new WP_REST_Response(array_map('hippo_crm_costo_to_array', $posts), 200);
}

function hippo_crm_get_costo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_costo');
    if (!$post) return new WP_REST_Response(['error' => 'Costo no encontrado'], 404);
    return new WP_REST_Response(hippo_crm_costo_to_array($post), 200);
}

function hippo_crm_categoria_invalida($params) {
    return !empty($params['categoria']) && !in_array($params['categoria'], HIPPO_CRM_COSTO_CATEGORIAS, true);
}

function hippo_crm_save_costo_meta($id, $params) {
    hippo_crm_save_meta($id, $params, HIPPO_CRM_COSTO_CAMPOS);
    hippo_crm_save_moneda($id, $params);
}

function hippo_crm_create_costo($request) {
    $params = $request->get_json_params();
    if (empty($params['nombre_costo'])) return new WP_REST_Response(['error' => 'nombre_costo es obligatorio'], 400);
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);
    if (hippo_crm_categoria_invalida($params)) return new WP_REST_Response(['error' => 'Categoría inválida'], 400);

    $id = wp_insert_post(['post_type' => 'hippo_costo', 'post_title' => sanitize_text_field($params['nombre_costo']), 'post_status' => 'publish']);
    hippo_crm_save_costo_meta($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_costo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_costo');
    if (!$post) return new WP_REST_Response(['error' => 'Costo no encontrado'], 404);

    $params = $request->get_json_params();
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);
    if (hippo_crm_categoria_invalida($params)) return new WP_REST_Response(['error' => 'Categoría inválida'], 400);

    if (!empty($params['nombre_costo'])) wp_update_post(['ID' => $post->ID, 'post_title' => sanitize_text_field($params['nombre_costo'])]);
    hippo_crm_save_costo_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

// A la papelera, junto con sus pagos (se recuperan desde la papelera de WordPress)
function hippo_crm_delete_costo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_costo');
    if (!$post) return new WP_REST_Response(['error' => 'Costo no encontrado'], 404);

    foreach (hippo_crm_pagos_de_costo($post->ID) as $pago) wp_delete_post($pago['id'], false);
    wp_delete_post($post->ID, false);
    return new WP_REST_Response(['success' => true], 200);
}
