<?php
// Hippo CRM — Pagos de costos

if (!defined('ABSPATH')) exit;

function hippo_crm_pago_costo_to_array($post) {
    return [
        'id'         => $post->ID,
        'costoId'    => (int) get_post_meta($post->ID, 'costo_id', true),
        'fecha'      => get_post_meta($post->ID, 'fecha', true) ?: null,
        'periodo'    => get_post_meta($post->ID, 'periodo', true) ?: null,
        'monto'      => (float) get_post_meta($post->ID, 'monto', true),
        'moneda'     => get_post_meta($post->ID, 'moneda', true) ?: 'USD',
        'metodoPago' => get_post_meta($post->ID, 'metodo_pago', true) ?: null,
        'notas'      => get_post_meta($post->ID, 'notas', true) ?: null,
    ];
}

function hippo_crm_pagos_de_costo($costo_id) {
    $posts = get_posts([
        'post_type' => 'hippo_pago_costo', 'numberposts' => -1,
        'meta_key' => 'costo_id', 'meta_value' => (int) $costo_id,
    ]);
    return array_map('hippo_crm_pago_costo_to_array', $posts);
}

function hippo_crm_periodo_invalido($params) {
    return isset($params['periodo']) && !preg_match('/^\d{4}(-(0[1-9]|1[0-2]))?$/', (string) $params['periodo']);
}

function hippo_crm_save_pago_costo_meta($id, $params) {
    hippo_crm_save_meta($id, $params, HIPPO_CRM_PAGO_COSTO_CAMPOS);
    hippo_crm_save_meta($id, $params, ['notas'], 'sanitize_textarea_field');
    hippo_crm_save_moneda($id, $params);
}

function hippo_crm_get_pago_costo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_pago_costo');
    if (!$post) return new WP_REST_Response(['error' => 'Pago no encontrado'], 404);
    return new WP_REST_Response(hippo_crm_pago_costo_to_array($post), 200);
}

function hippo_crm_create_pago_costo($request) {
    $params = $request->get_json_params();
    $costo = hippo_crm_get_post_of_type($params['costo_id'] ?? 0, 'hippo_costo');
    if (!$costo) return new WP_REST_Response(['error' => 'costo_id inválido'], 400);
    if (empty($params['fecha']) || empty($params['periodo']) || !isset($params['monto'])) {
        return new WP_REST_Response(['error' => 'fecha, periodo y monto son obligatorios'], 400);
    }
    if (hippo_crm_periodo_invalido($params)) return new WP_REST_Response(['error' => 'Período inválido'], 400);
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);

    $id = wp_insert_post([
        'post_type'   => 'hippo_pago_costo',
        'post_title'  => sanitize_text_field($costo->post_title . ' — ' . $params['periodo']),
        'post_status' => 'publish',
    ]);
    update_post_meta($id, 'costo_id', $costo->ID);
    hippo_crm_save_pago_costo_meta($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_pago_costo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_pago_costo');
    if (!$post) return new WP_REST_Response(['error' => 'Pago no encontrado'], 404);

    $params = $request->get_json_params();
    if (hippo_crm_periodo_invalido($params)) return new WP_REST_Response(['error' => 'Período inválido'], 400);
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);
    foreach (['fecha', 'periodo', 'monto'] as $f) {
        if (array_key_exists($f, $params) && ($params[$f] === null || $params[$f] === '')) {
            return new WP_REST_Response(['error' => "$f es obligatorio"], 400);
        }
    }

    hippo_crm_save_pago_costo_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_pago_costo($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_pago_costo');
    if (!$post) return new WP_REST_Response(['error' => 'Pago no encontrado'], 404);
    wp_delete_post($post->ID, false);
    return new WP_REST_Response(['success' => true], 200);
}
