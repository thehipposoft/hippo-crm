<?php
// Hippo CRM — Pagos

if (!defined('ABSPATH')) exit;

function hippo_crm_pago_to_array($post) {
    $proyecto_id = (int) get_post_meta($post->ID, 'proyecto_id', true);
    $proyecto = get_post($proyecto_id);
    $cliente_nombre = null;

    if ($proyecto) {
        $cliente_id = (int) get_post_meta($proyecto->ID, 'cliente_id', true);
        $cliente = get_post($cliente_id);
        $cliente_nombre = $cliente ? $cliente->post_title : null;
    }

    return [
        'id'             => $post->ID,
        'proyectoId'     => $proyecto_id,
        'proyectoNombre' => $proyecto ? $proyecto->post_title : null,
        'clienteNombre'  => $cliente_nombre,
        'fecha'          => get_post_meta($post->ID, 'fecha', true) ?: null,
        'monto'          => (float) get_post_meta($post->ID, 'monto', true),
        'moneda'         => get_post_meta($post->ID, 'moneda', true) ?: 'USD',
        'medioPago'      => get_post_meta($post->ID, 'medio_pago', true) ?: null,
        'notas'          => get_post_meta($post->ID, 'notas', true) ?: null,
    ];
}

function hippo_crm_get_pagos() {
    $posts = get_posts(['post_type' => 'hippo_pago', 'numberposts' => -1]);
    return new WP_REST_Response(array_map('hippo_crm_pago_to_array', $posts), 200);
}

function hippo_crm_get_pagos_by_proyecto($request) {
    $posts = get_posts([
        'post_type' => 'hippo_pago', 'numberposts' => -1,
        'meta_key' => 'proyecto_id', 'meta_value' => (int) $request->get_param('id'),
    ]);
    return new WP_REST_Response(array_map('hippo_crm_pago_to_array', $posts), 200);
}

function hippo_crm_get_pago($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_pago');
    if (!$post) return new WP_REST_Response(['error' => 'Pago no encontrado'], 404);
    return new WP_REST_Response(hippo_crm_pago_to_array($post), 200);
}

function hippo_crm_save_pago_meta($id, $params) {
    if (isset($params['proyecto_id'])) update_post_meta($id, 'proyecto_id', (int) $params['proyecto_id']);
    hippo_crm_save_meta($id, $params, HIPPO_CRM_PAGO_CAMPOS);
    // textarea: sanitize_text_field borraba los saltos de línea de las notas
    hippo_crm_save_meta($id, $params, ['notas'], 'sanitize_textarea_field');
    hippo_crm_save_moneda($id, $params);
}

function hippo_crm_create_pago($request) {
    $params = $request->get_json_params();
    if (empty($params['proyecto_id'])) return new WP_REST_Response(['error' => 'proyecto_id es obligatorio'], 400);
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);

    $proyecto = get_post((int) $params['proyecto_id']);
    $titulo = ($proyecto ? $proyecto->post_title : 'Proyecto') . ' — ' . ($params['fecha'] ?? '');

    $id = wp_insert_post(['post_type' => 'hippo_pago', 'post_title' => sanitize_text_field($titulo), 'post_status' => 'publish']);
    hippo_crm_save_pago_meta($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_pago($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_pago');
    if (!$post) return new WP_REST_Response(['error' => 'Pago no encontrado'], 404);

    $params = $request->get_json_params();
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);

    hippo_crm_save_pago_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_pago($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_pago');
    if (!$post) return new WP_REST_Response(['error' => 'Pago no encontrado'], 404);

    wp_delete_post($post->ID, false); // false = a la papelera, no borrado permanente

    return new WP_REST_Response(['success' => true], 200);
}
