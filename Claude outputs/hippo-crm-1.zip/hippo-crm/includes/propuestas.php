<?php
// Hippo CRM — Propuestas y cotizaciones, plantillas y cuentas bancarias

if (!defined('ABSPATH')) exit;

const HIPPO_CRM_PROPUESTA_TIPOS   = ['PROPUESTA', 'COTIZACION'];
const HIPPO_CRM_PROPUESTA_ESTADOS = ['BORRADOR', 'ENVIADA', 'ACEPTADA', 'RECHAZADA'];
const HIPPO_CRM_IDIOMAS           = ['es', 'en'];
const HIPPO_CRM_MAX_ITEMS         = 100;
const HIPPO_CRM_MAX_SECCIONES     = 40;
const HIPPO_CRM_MAX_TEXTO         = 20000;

// ==== Ítems, secciones y cuentas (se guardan como JSON en un meta) ====

// Devuelve [ítems, null] o [null, error]
function hippo_crm_normalizar_items($items) {
    if (!is_array($items)) return [null, 'items debe ser una lista'];
    if (count($items) > HIPPO_CRM_MAX_ITEMS) return [null, 'Demasiados ítems'];
    $salida = [];
    foreach (array_values($items) as $i => $item) {
        if (!is_array($item)) return [null, 'Ítem inválido'];
        $descripcion = sanitize_text_field($item['descripcion'] ?? '');
        if ($descripcion === '') return [null, 'Cada ítem necesita una descripción (ítem ' . ($i + 1) . ')'];
        $cantidad = $item['cantidad'] ?? 1;
        $precio = $item['precio'] ?? null;
        if (!is_numeric($cantidad) || (float) $cantidad <= 0) return [null, 'Cantidad inválida (ítem ' . ($i + 1) . ')'];
        if (!is_numeric($precio) || (float) $precio < 0) return [null, 'Precio inválido (ítem ' . ($i + 1) . ')'];
        $salida[] = [
            'descripcion' => $descripcion,
            'detalle'     => hippo_crm_texto_o_null($item['detalle'] ?? null),
            'plazo'       => sanitize_text_field($item['plazo'] ?? '') ?: null,
            'cantidad'    => (float) $cantidad,
            'precio'      => (float) $precio,
        ];
    }
    return [$salida, null];
}

function hippo_crm_normalizar_secciones($secciones) {
    if (!is_array($secciones)) return [null, 'secciones debe ser una lista'];
    if (count($secciones) > HIPPO_CRM_MAX_SECCIONES) return [null, 'Demasiadas secciones'];
    $salida = [];
    foreach (array_values($secciones) as $i => $s) {
        if (!is_array($s)) return [null, 'Sección inválida'];
        $titulo = sanitize_text_field($s['titulo'] ?? '');
        if ($titulo === '') return [null, 'Cada sección necesita un título (sección ' . ($i + 1) . ')'];
        $contenido = (string) ($s['contenido'] ?? '');
        if (strlen($contenido) > HIPPO_CRM_MAX_TEXTO) return [null, 'Sección demasiado larga: ' . $titulo];
        $salida[] = ['titulo' => $titulo, 'contenido' => sanitize_textarea_field($contenido)];
    }
    return [$salida, null];
}

function hippo_crm_texto_o_null($valor) {
    if ($valor === null) return null;
    $texto = sanitize_textarea_field((string) $valor);
    return $texto === '' ? null : $texto;
}

function hippo_crm_json_meta($post_id, $key) {
    $valor = json_decode((string) get_post_meta($post_id, $key, true), true);
    return is_array($valor) ? $valor : [];
}

function hippo_crm_guardar_json($post_id, $key, $valor) {
    // wp_slash: update_post_meta saca las barras y rompería los \n y \" del JSON
    update_post_meta($post_id, $key, wp_slash(wp_json_encode($valor, JSON_UNESCAPED_UNICODE)));
}

// IDs de cuentas bancarias válidas, en el orden recibido
function hippo_crm_normalizar_cuentas($ids) {
    if (!is_array($ids)) return [null, 'cuentas debe ser una lista'];
    $salida = [];
    foreach ($ids as $id) {
        if (!hippo_crm_get_post_of_type($id, 'hippo_cuenta_banco')) return [null, 'Cuenta bancaria inválida'];
        if (!in_array((int) $id, $salida, true)) $salida[] = (int) $id;
    }
    return [$salida, null];
}

// ==== Cuentas bancarias ====

function hippo_crm_cuenta_to_array($post) {
    return [
        'id'      => $post->ID,
        'nombre'  => $post->post_title,
        'moneda'  => get_post_meta($post->ID, 'moneda', true) ?: null,
        'detalle' => $post->post_content,
    ];
}

function hippo_crm_get_cuentas() {
    $posts = get_posts(['post_type' => 'hippo_cuenta_banco', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC']);
    return new WP_REST_Response(array_map('hippo_crm_cuenta_to_array', $posts), 200);
}

function hippo_crm_get_cuenta($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cuenta_banco');
    if (!$post) return new WP_REST_Response(['error' => 'Cuenta no encontrada'], 404);
    return new WP_REST_Response(hippo_crm_cuenta_to_array($post), 200);
}

function hippo_crm_create_cuenta($request) {
    $params = $request->get_json_params();
    if (empty($params['nombre']) || empty($params['detalle'])) return new WP_REST_Response(['error' => 'nombre y detalle son obligatorios'], 400);
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);
    $id = wp_insert_post([
        'post_type'    => 'hippo_cuenta_banco',
        'post_title'   => sanitize_text_field($params['nombre']),
        'post_content' => sanitize_textarea_field($params['detalle']),
        'post_status'  => 'publish',
    ]);
    hippo_crm_save_moneda($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_cuenta($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cuenta_banco');
    if (!$post) return new WP_REST_Response(['error' => 'Cuenta no encontrada'], 404);
    $params = $request->get_json_params();
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);
    if (array_key_exists('nombre', $params) && empty($params['nombre'])) return new WP_REST_Response(['error' => 'nombre es obligatorio'], 400);
    if (array_key_exists('detalle', $params) && empty($params['detalle'])) return new WP_REST_Response(['error' => 'detalle es obligatorio'], 400);

    $cambios = ['ID' => $post->ID];
    if (!empty($params['nombre'])) $cambios['post_title'] = sanitize_text_field($params['nombre']);
    if (!empty($params['detalle'])) $cambios['post_content'] = sanitize_textarea_field($params['detalle']);
    if (count($cambios) > 1) wp_update_post($cambios);
    hippo_crm_save_moneda($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_cuenta($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_cuenta_banco');
    if (!$post) return new WP_REST_Response(['error' => 'Cuenta no encontrada'], 404);
    wp_delete_post($post->ID, false);
    return new WP_REST_Response(['success' => true], 200);
}

// ==== Plantillas ====

function hippo_crm_plantilla_to_array($post) {
    return [
        'id'        => $post->ID,
        'nombre'    => $post->post_title,
        'tipo'      => get_post_meta($post->ID, 'tipo', true) ?: 'PROPUESTA',
        'idioma'    => get_post_meta($post->ID, 'idioma', true) ?: 'es',
        'secciones' => hippo_crm_json_meta($post->ID, 'secciones'),
        'items'     => hippo_crm_json_meta($post->ID, 'items'),
        'notas'     => get_post_meta($post->ID, 'notas', true) ?: null,
    ];
}

function hippo_crm_get_plantillas() {
    $posts = get_posts(['post_type' => 'hippo_plantilla', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC']);
    return new WP_REST_Response(array_map('hippo_crm_plantilla_to_array', $posts), 200);
}

function hippo_crm_get_plantilla($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_plantilla');
    if (!$post) return new WP_REST_Response(['error' => 'Plantilla no encontrada'], 404);
    return new WP_REST_Response(hippo_crm_plantilla_to_array($post), 200);
}

// Valida y guarda tipo, idioma, secciones, ítems y notas (comparten plantillas y propuestas)
function hippo_crm_guardar_contenido($id, $params) {
    if (array_key_exists('secciones', $params)) {
        [$secciones, $error] = hippo_crm_normalizar_secciones($params['secciones'] ?? []);
        if ($error) return $error;
        hippo_crm_guardar_json($id, 'secciones', $secciones);
    }
    if (array_key_exists('items', $params)) {
        [$items, $error] = hippo_crm_normalizar_items($params['items'] ?? []);
        if ($error) return $error;
        hippo_crm_guardar_json($id, 'items', $items);
    }
    if (array_key_exists('notas', $params)) {
        $notas = hippo_crm_texto_o_null($params['notas']);
        if ($notas === null) delete_post_meta($id, 'notas');
        else update_post_meta($id, 'notas', $notas);
    }
    hippo_crm_save_meta($id, $params, ['tipo', 'idioma']);
    return null;
}

function hippo_crm_validar_tipo_idioma($params) {
    if (isset($params['tipo']) && !in_array($params['tipo'], HIPPO_CRM_PROPUESTA_TIPOS, true)) return 'Tipo inválido';
    if (isset($params['idioma']) && !in_array($params['idioma'], HIPPO_CRM_IDIOMAS, true)) return 'Idioma inválido';
    if (isset($params['items'])) { [, $e] = hippo_crm_normalizar_items($params['items']); if ($e) return $e; }
    if (isset($params['secciones'])) { [, $e] = hippo_crm_normalizar_secciones($params['secciones']); if ($e) return $e; }
    return null;
}

function hippo_crm_create_plantilla($request) {
    $params = $request->get_json_params();
    if (empty($params['nombre'])) return new WP_REST_Response(['error' => 'nombre es obligatorio'], 400);
    $error = hippo_crm_validar_tipo_idioma($params);
    if ($error) return new WP_REST_Response(['error' => $error], 400);

    $id = wp_insert_post([
        'post_type' => 'hippo_plantilla', 'post_title' => sanitize_text_field($params['nombre']), 'post_status' => 'publish',
    ]);
    hippo_crm_guardar_contenido($id, $params + ['tipo' => 'PROPUESTA', 'idioma' => 'es']);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_plantilla($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_plantilla');
    if (!$post) return new WP_REST_Response(['error' => 'Plantilla no encontrada'], 404);
    $params = $request->get_json_params();
    $error = hippo_crm_validar_tipo_idioma($params);
    if ($error) return new WP_REST_Response(['error' => $error], 400);
    if (!empty($params['nombre'])) wp_update_post(['ID' => $post->ID, 'post_title' => sanitize_text_field($params['nombre'])]);
    hippo_crm_guardar_contenido($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_plantilla($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_plantilla');
    if (!$post) return new WP_REST_Response(['error' => 'Plantilla no encontrada'], 404);
    wp_delete_post($post->ID, false);
    return new WP_REST_Response(['success' => true], 200);
}

// ==== Propuestas y cotizaciones ====

function hippo_crm_propuesta_to_array($post) {
    $cliente_id = (int) get_post_meta($post->ID, 'cliente_id', true);
    $cliente = $cliente_id ? get_post($cliente_id) : null;
    $proyecto_id = (int) get_post_meta($post->ID, 'proyecto_id', true);
    $proyecto = $proyecto_id ? get_post($proyecto_id) : null;
    $datos = hippo_crm_plantilla_to_array($post);
    unset($datos['nombre']);

    return $datos + [
        'titulo'              => $post->post_title,
        'resumen'             => get_post_meta($post->ID, 'resumen', true) ?: null,
        'estado'              => get_post_meta($post->ID, 'estado', true) ?: 'BORRADOR',
        'clienteId'           => $cliente ? $cliente->ID : null,
        'clienteNombre'       => $cliente ? $cliente->post_title : null,
        'proyectoId'          => $proyecto ? $proyecto->ID : null,
        'proyectoNombre'      => $proyecto ? $proyecto->post_title : null,
        'moneda'              => get_post_meta($post->ID, 'moneda', true) ?: null,
        'fecha'               => get_post_meta($post->ID, 'fecha', true) ?: substr($post->post_date, 0, 10),
        'fechaVencimiento'    => get_post_meta($post->ID, 'fecha_vencimiento', true) ?: null,
        'descuento'           => (float) get_post_meta($post->ID, 'descuento', true),
        'cuentas'             => array_map('intval', hippo_crm_json_meta($post->ID, 'cuentas')),
        'token'               => get_post_meta($post->ID, 'token', true) ?: null,
        // Fechas y horas en UTC (ISO 8601)
        'enviadaEl'           => get_post_meta($post->ID, 'enviada_el', true) ?: null,
        'vistaEl'             => get_post_meta($post->ID, 'vista_el', true) ?: null,
        'respondidaEl'        => get_post_meta($post->ID, 'respondida_el', true) ?: null,
        'respuestaNombre'     => get_post_meta($post->ID, 'respuesta_nombre', true) ?: null,
        'respuestaComentario' => get_post_meta($post->ID, 'respuesta_comentario', true) ?: null,
    ];
}

function hippo_crm_ahora_utc() {
    return gmdate('Y-m-d\TH:i:s\Z');
}

function hippo_crm_get_propuestas() {
    $posts = get_posts(['post_type' => 'hippo_propuesta', 'numberposts' => -1]);
    return new WP_REST_Response(array_map('hippo_crm_propuesta_to_array', $posts), 200);
}

function hippo_crm_get_propuesta($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_propuesta');
    if (!$post) return new WP_REST_Response(['error' => 'Propuesta no encontrada'], 404);
    return new WP_REST_Response(hippo_crm_propuesta_to_array($post), 200);
}

function hippo_crm_validar_propuesta($params, $es_alta) {
    $error = hippo_crm_validar_tipo_idioma($params);
    if ($error) return $error;
    if ($es_alta || array_key_exists('cliente_id', $params)) {
        if (empty($params['cliente_id']) || !hippo_crm_get_post_of_type($params['cliente_id'], 'hippo_cliente')) return 'Cliente inválido';
    }
    if (!empty($params['proyecto_id']) && !hippo_crm_get_post_of_type($params['proyecto_id'], 'hippo_proyecto')) return 'Proyecto inválido';
    if (isset($params['estado']) && !in_array($params['estado'], HIPPO_CRM_PROPUESTA_ESTADOS, true)) return 'Estado inválido';
    if (hippo_crm_moneda_param_invalida($params)) return 'Moneda inválida';
    foreach (['fecha', 'fecha_vencimiento'] as $f) {
        if (!empty($params[$f]) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $params[$f])) return 'Fecha inválida';
    }
    if (isset($params['descuento']) && $params['descuento'] !== '' && (!is_numeric($params['descuento']) || (float) $params['descuento'] < 0)) return 'Descuento inválido';
    if (isset($params['cuentas'])) { [, $e] = hippo_crm_normalizar_cuentas($params['cuentas']); if ($e) return $e; }
    return null;
}

function hippo_crm_save_propuesta_meta($id, $params) {
    hippo_crm_guardar_contenido($id, $params);
    hippo_crm_save_meta($id, $params, ['fecha', 'fecha_vencimiento', 'descuento']);
    hippo_crm_save_moneda($id, $params);
    if (array_key_exists('resumen', $params)) {
        $resumen = hippo_crm_texto_o_null($params['resumen']);
        if ($resumen === null) delete_post_meta($id, 'resumen');
        else update_post_meta($id, 'resumen', $resumen);
    }
    foreach (['cliente_id', 'proyecto_id'] as $f) {
        if (!array_key_exists($f, $params)) continue;
        if (empty($params[$f])) delete_post_meta($id, $f);
        else update_post_meta($id, $f, (int) $params[$f]);
    }
    if (array_key_exists('cuentas', $params)) {
        [$cuentas] = hippo_crm_normalizar_cuentas($params['cuentas'] ?? []);
        hippo_crm_guardar_json($id, 'cuentas', $cuentas);
    }
    if (array_key_exists('estado', $params)) hippo_crm_cambiar_estado_propuesta($id, $params['estado']);
}

// Cambio de estado desde el CRM (ej. el cliente aceptó por WhatsApp)
function hippo_crm_cambiar_estado_propuesta($id, $estado) {
    update_post_meta($id, 'estado', $estado);
    if ($estado !== 'BORRADOR' && !get_post_meta($id, 'enviada_el', true)) update_post_meta($id, 'enviada_el', hippo_crm_ahora_utc());
    if (in_array($estado, ['ACEPTADA', 'RECHAZADA'], true)) {
        if (!get_post_meta($id, 'respondida_el', true)) update_post_meta($id, 'respondida_el', hippo_crm_ahora_utc());
    } else {
        // Vuelve a estar abierta: se borra la respuesta anterior
        foreach (['respondida_el', 'respuesta_nombre', 'respuesta_comentario'] as $k) delete_post_meta($id, $k);
    }
    if ($estado === 'BORRADOR') delete_post_meta($id, 'enviada_el');
}

function hippo_crm_create_propuesta($request) {
    $params = $request->get_json_params();
    if (empty($params['titulo'])) return new WP_REST_Response(['error' => 'titulo es obligatorio'], 400);
    $error = hippo_crm_validar_propuesta($params, true);
    if ($error) return new WP_REST_Response(['error' => $error], 400);

    $id = wp_insert_post([
        'post_type' => 'hippo_propuesta', 'post_title' => sanitize_text_field($params['titulo']), 'post_status' => 'publish',
    ]);
    // El link público existe desde el alta, pero no se ve mientras sea BORRADOR
    update_post_meta($id, 'token', bin2hex(random_bytes(32)));
    hippo_crm_save_propuesta_meta($id, $params + ['tipo' => 'PROPUESTA', 'idioma' => 'es', 'estado' => 'BORRADOR', 'fecha' => current_time('Y-m-d')]);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_propuesta($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_propuesta');
    if (!$post) return new WP_REST_Response(['error' => 'Propuesta no encontrada'], 404);
    $params = $request->get_json_params();
    if (array_key_exists('titulo', $params) && empty($params['titulo'])) return new WP_REST_Response(['error' => 'titulo es obligatorio'], 400);
    $error = hippo_crm_validar_propuesta($params, false);
    if ($error) return new WP_REST_Response(['error' => $error], 400);

    if (!empty($params['titulo'])) wp_update_post(['ID' => $post->ID, 'post_title' => sanitize_text_field($params['titulo'])]);
    hippo_crm_save_propuesta_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_propuesta($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_propuesta');
    if (!$post) return new WP_REST_Response(['error' => 'Propuesta no encontrada'], 404);
    wp_delete_post($post->ID, false);
    return new WP_REST_Response(['success' => true], 200);
}

// ==== Link público: ver, aceptar y rechazar ====

function hippo_crm_propuesta_por_token($token) {
    $token = (string) $token;
    $posts = get_posts(['post_type' => 'hippo_propuesta', 'numberposts' => 1, 'meta_key' => 'token', 'meta_value' => $token]);
    if (empty($posts) || !hash_equals((string) get_post_meta($posts[0]->ID, 'token', true), $token)) return null;
    // Un borrador todavía no existe para el cliente
    if ((get_post_meta($posts[0]->ID, 'estado', true) ?: 'BORRADOR') === 'BORRADOR') return null;
    return $posts[0];
}

function hippo_crm_propuesta_publica_array($post) {
    $datos = hippo_crm_propuesta_to_array($post);
    $cliente = $datos['clienteId'] ? get_post($datos['clienteId']) : null;
    $cuentas = [];
    foreach ($datos['cuentas'] as $cuenta_id) {
        $cuenta = hippo_crm_get_post_of_type($cuenta_id, 'hippo_cuenta_banco');
        if ($cuenta) $cuentas[] = ['nombre' => $cuenta->post_title, 'detalle' => $cuenta->post_content];
    }
    $publico = array_intersect_key($datos, array_flip([
        'id', 'tipo', 'idioma', 'titulo', 'resumen', 'estado', 'moneda', 'fecha', 'fechaVencimiento',
        'descuento', 'secciones', 'items', 'notas', 'respondidaEl', 'respuestaNombre',
    ]));
    $publico['cliente'] = [
        'nombre'   => $cliente ? $cliente->post_title : null,
        'contacto' => $cliente ? (get_post_meta($cliente->ID, 'contacto', true) ?: null) : null,
        'pais'     => $cliente ? (get_post_meta($cliente->ID, 'pais', true) ?: null) : null,
    ];
    $publico['cuentas'] = $cuentas;
    $publico['vencida'] = hippo_crm_propuesta_vencida($post->ID);
    return $publico;
}

function hippo_crm_propuesta_vencida($id) {
    $vence = get_post_meta($id, 'fecha_vencimiento', true);
    return $vence && $vence < current_time('Y-m-d');
}

function hippo_crm_propuesta_publica($request) {
    $post = hippo_crm_propuesta_por_token($request->get_param('token'));
    if (!$post) return new WP_REST_Response(['error' => 'Link inválido'], 404);
    // Primera vez que el cliente la abre (?vista=0 la usa el CRM para previsualizar sin marcarla)
    if ($request->get_param('vista') !== '0' && !get_post_meta($post->ID, 'vista_el', true)) {
        update_post_meta($post->ID, 'vista_el', hippo_crm_ahora_utc());
    }
    $respuesta = new WP_REST_Response(hippo_crm_propuesta_publica_array($post), 200);
    $respuesta->header('Cache-Control', 'no-store');
    return $respuesta;
}

function hippo_crm_responder_propuesta($request) {
    $post = hippo_crm_propuesta_por_token($request->get_param('token'));
    if (!$post) return new WP_REST_Response(['error' => 'Link inválido'], 404);
    $params = $request->get_json_params() ?: [];
    $accion = $params['accion'] ?? '';
    if (!in_array($accion, ['ACEPTAR', 'RECHAZAR'], true)) return new WP_REST_Response(['error' => 'Acción inválida'], 400);

    $nombre = mb_substr(sanitize_text_field($params['nombre'] ?? ''), 0, 120);
    $comentario = mb_substr(sanitize_textarea_field($params['comentario'] ?? ''), 0, 2000);
    if ($accion === 'ACEPTAR' && $nombre === '') return new WP_REST_Response(['error' => 'El nombre es obligatorio para aceptar'], 400);

    // Una sola respuesta: después solo se cambia desde el CRM
    if (get_post_meta($post->ID, 'estado', true) !== 'ENVIADA') return new WP_REST_Response(['error' => 'Ya fue respondida'], 409);
    if (hippo_crm_propuesta_vencida($post->ID)) return new WP_REST_Response(['error' => 'La propuesta está vencida'], 410);

    $estado = $accion === 'ACEPTAR' ? 'ACEPTADA' : 'RECHAZADA';
    update_post_meta($post->ID, 'estado', $estado);
    update_post_meta($post->ID, 'respondida_el', hippo_crm_ahora_utc());
    if ($nombre !== '') update_post_meta($post->ID, 'respuesta_nombre', $nombre);
    else delete_post_meta($post->ID, 'respuesta_nombre');
    if ($comentario !== '') update_post_meta($post->ID, 'respuesta_comentario', $comentario);
    else delete_post_meta($post->ID, 'respuesta_comentario');

    hippo_crm_avisar_respuesta($post, $estado, $nombre, $comentario);
    return new WP_REST_Response(hippo_crm_propuesta_publica_array(get_post($post->ID)), 200);
}

// Email al equipo. Destino: HIPPO_CRM_EMAIL_AVISOS (wp-config.php) o el email del admin.
function hippo_crm_avisar_respuesta($post, $estado, $nombre, $comentario) {
    $destino = defined('HIPPO_CRM_EMAIL_AVISOS') ? HIPPO_CRM_EMAIL_AVISOS : get_option('admin_email');
    $crm = defined('HIPPO_CRM_URL') ? HIPPO_CRM_URL : 'https://crm.thehipposoft.com';
    $cliente = get_post((int) get_post_meta($post->ID, 'cliente_id', true));
    $tipo = get_post_meta($post->ID, 'tipo', true) === 'COTIZACION' ? 'Cotización' : 'Propuesta';
    $verbo = $estado === 'ACEPTADA' ? 'aceptada' : 'rechazada';

    $asunto = sprintf('%s %s: %s%s', $tipo, $verbo, $post->post_title, $cliente ? ' (' . $cliente->post_title . ')' : '');
    $lineas = [
        sprintf('%s "%s" fue %s.', $tipo, $post->post_title, $verbo),
        $cliente ? 'Cliente: ' . $cliente->post_title : null,
        $nombre !== '' ? 'Respondió: ' . $nombre : null,
        $comentario !== '' ? "Comentario:\n" . $comentario : null,
        '',
        'Ver en el CRM: ' . rtrim($crm, '/') . '/propuestas/' . $post->ID,
    ];
    wp_mail($destino, $asunto, implode("\n", array_filter($lineas, fn($l) => $l !== null)));
}
