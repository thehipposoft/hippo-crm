<?php
// Hippo CRM — Tareas

if (!defined('ABSPATH')) exit;

function hippo_crm_tarea_to_array($post) {
    $proyecto_id = (int) get_post_meta($post->ID, 'proyecto_id', true);
    $proyecto = $proyecto_id ? get_post($proyecto_id) : null;
    $cliente = $proyecto ? get_post((int) get_post_meta($proyecto->ID, 'cliente_id', true)) : null;
    $responsable_id = (int) get_post_meta($post->ID, 'responsable_id', true);
    $responsable = $responsable_id ? get_user_by('id', $responsable_id) : null;

    return [
        'id'                => $post->ID,
        'titulo'            => $post->post_title,
        'descripcion'       => $post->post_content ?: null,
        'estado'            => get_post_meta($post->ID, 'estado', true) ?: 'PENDIENTE',
        'prioridad'         => get_post_meta($post->ID, 'prioridad', true) ?: 'MEDIA',
        'responsableId'     => $responsable ? $responsable->ID : null,
        'responsableNombre' => $responsable ? $responsable->display_name : null,
        'fechaLimite'       => get_post_meta($post->ID, 'fecha_limite', true) ?: null,
        'proyectoId'        => $proyecto ? $proyecto->ID : null,
        'proyectoNombre'    => $proyecto ? $proyecto->post_title : null,
        'clienteNombre'     => $cliente ? $cliente->post_title : null,
        'creada'            => substr($post->post_date, 0, 10),
        // Se completa sola al pasar a HECHA (para ordenar y limpiar las viejas)
        'fechaHecha'        => get_post_meta($post->ID, 'fecha_hecha', true) ?: null,
    ];
}

function hippo_crm_get_tareas() {
    $posts = get_posts(['post_type' => 'hippo_tarea', 'numberposts' => -1]);
    return new WP_REST_Response(array_map('hippo_crm_tarea_to_array', $posts), 200);
}

function hippo_crm_get_tarea($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_tarea');
    if (!$post) return new WP_REST_Response(['error' => 'Tarea no encontrada'], 404);
    return new WP_REST_Response(hippo_crm_tarea_to_array($post), 200);
}

// Devuelve un mensaje de error o null si los datos son válidos
function hippo_crm_validar_tarea($params) {
    if (isset($params['estado']) && !in_array($params['estado'], HIPPO_CRM_TAREA_ESTADOS, true)) return 'Estado inválido';
    if (isset($params['prioridad']) && !in_array($params['prioridad'], HIPPO_CRM_TAREA_PRIORIDADES, true)) return 'Prioridad inválida';
    if (!empty($params['responsable_id']) && !get_user_by('id', (int) $params['responsable_id'])) return 'Responsable inválido';
    if (!empty($params['proyecto_id']) && !hippo_crm_get_post_of_type($params['proyecto_id'], 'hippo_proyecto')) return 'Proyecto inválido';
    return null;
}

function hippo_crm_save_tarea_meta($id, $params) {
    hippo_crm_save_meta($id, $params, ['estado', 'prioridad', 'fecha_limite']);
    foreach (['responsable_id', 'proyecto_id'] as $f) {
        if (!array_key_exists($f, $params)) continue;
        if (empty($params[$f])) delete_post_meta($id, $f);
        else update_post_meta($id, $f, (int) $params[$f]);
    }
    if (array_key_exists('estado', $params)) {
        $era_hecha = (bool) get_post_meta($id, 'fecha_hecha', true);
        if ($params['estado'] === 'HECHA' && !$era_hecha) update_post_meta($id, 'fecha_hecha', current_time('Y-m-d'));
        if ($params['estado'] !== 'HECHA') delete_post_meta($id, 'fecha_hecha');
    }
}

function hippo_crm_create_tarea($request) {
    $params = $request->get_json_params();
    if (empty($params['titulo'])) return new WP_REST_Response(['error' => 'titulo es obligatorio'], 400);
    $error = hippo_crm_validar_tarea($params);
    if ($error) return new WP_REST_Response(['error' => $error], 400);

    $id = wp_insert_post([
        'post_type'    => 'hippo_tarea',
        'post_title'   => sanitize_text_field($params['titulo']),
        'post_content' => sanitize_textarea_field($params['descripcion'] ?? ''),
        'post_status'  => 'publish',
    ]);
    hippo_crm_save_tarea_meta($id, $params + ['estado' => 'PENDIENTE', 'prioridad' => 'MEDIA']);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_tarea($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_tarea');
    if (!$post) return new WP_REST_Response(['error' => 'Tarea no encontrada'], 404);

    $params = $request->get_json_params();
    $error = hippo_crm_validar_tarea($params);
    if ($error) return new WP_REST_Response(['error' => $error], 400);

    $cambios = ['ID' => $post->ID];
    if (!empty($params['titulo'])) $cambios['post_title'] = sanitize_text_field($params['titulo']);
    if (array_key_exists('descripcion', $params)) $cambios['post_content'] = sanitize_textarea_field($params['descripcion'] ?? '');
    if (count($cambios) > 1) wp_update_post($cambios);

    hippo_crm_save_tarea_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_tarea($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_tarea');
    if (!$post) return new WP_REST_Response(['error' => 'Tarea no encontrada'], 404);
    wp_delete_post($post->ID, false); // a la papelera
    return new WP_REST_Response(['success' => true], 200);
}

// Equipo: usuarios que entraron al CRM al menos una vez (tienen token)
function hippo_crm_get_usuarios() {
    $usuarios = get_users(['meta_key' => 'hippo_crm_token', 'meta_compare' => 'EXISTS', 'orderby' => 'display_name']);
    return new WP_REST_Response(array_map(function ($u) {
        return ['id' => $u->ID, 'nombre' => $u->display_name];
    }, $usuarios), 200);
}
