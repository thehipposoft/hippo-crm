<?php
// Hippo CRM — Unidades

if (!defined('ABSPATH')) exit;

function hippo_crm_unidad_to_array($post) {
    return [
        'id'         => $post->ID,
        'proyectoId' => (int) get_post_meta($post->ID, 'proyecto_id', true),
        'nombre'     => $post->post_title,
        'fechaAlta'  => get_post_meta($post->ID, 'fecha_alta', true) ?: null,
        'fechaBaja'  => get_post_meta($post->ID, 'fecha_baja', true) ?: null,
        'notas'      => get_post_meta($post->ID, 'notas', true) ?: null,
    ];
}

function hippo_crm_unidades_de($proyecto_id) {
    $posts = get_posts([
        'post_type' => 'hippo_unidad', 'numberposts' => -1,
        'meta_key' => 'proyecto_id', 'meta_value' => (int) $proyecto_id,
        'orderby' => 'title', 'order' => 'ASC',
    ]);
    return array_map('hippo_crm_unidad_to_array', $posts);
}

function hippo_crm_get_unidad($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_unidad');
    if (!$post) return new WP_REST_Response(['error' => 'Unidad no encontrada'], 404);
    return new WP_REST_Response(hippo_crm_unidad_to_array($post), 200);
}

function hippo_crm_save_unidad_meta($id, $params) {
    hippo_crm_save_meta($id, $params, HIPPO_CRM_UNIDAD_CAMPOS);
    hippo_crm_save_meta($id, $params, ['notas'], 'sanitize_textarea_field');
}

function hippo_crm_create_unidad($request) {
    $params = $request->get_json_params();
    if (!hippo_crm_get_post_of_type($params['proyecto_id'] ?? 0, 'hippo_proyecto')) {
        return new WP_REST_Response(['error' => 'proyecto_id inválido'], 400);
    }
    if (empty($params['nombre']) || empty($params['fecha_alta'])) {
        return new WP_REST_Response(['error' => 'nombre y fecha_alta son obligatorios'], 400);
    }

    $id = wp_insert_post(['post_type' => 'hippo_unidad', 'post_title' => sanitize_text_field($params['nombre']), 'post_status' => 'publish']);
    update_post_meta($id, 'proyecto_id', (int) $params['proyecto_id']);
    hippo_crm_save_unidad_meta($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_unidad($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_unidad');
    if (!$post) return new WP_REST_Response(['error' => 'Unidad no encontrada'], 404);

    $params = $request->get_json_params();
    if (array_key_exists('fecha_alta', $params) && empty($params['fecha_alta'])) {
        return new WP_REST_Response(['error' => 'fecha_alta es obligatoria'], 400);
    }
    if (!empty($params['nombre'])) wp_update_post(['ID' => $post->ID, 'post_title' => sanitize_text_field($params['nombre'])]);
    hippo_crm_save_unidad_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}

function hippo_crm_delete_unidad($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_unidad');
    if (!$post) return new WP_REST_Response(['error' => 'Unidad no encontrada'], 404);

    wp_delete_post($post->ID, false); // a la papelera
    return new WP_REST_Response(['success' => true], 200);
}
