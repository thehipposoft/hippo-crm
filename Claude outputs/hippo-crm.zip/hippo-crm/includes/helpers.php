<?php
// Hippo CRM — Constantes y helpers

if (!defined('ABSPATH')) exit;

const HIPPO_CRM_MONEDAS = ['USD', 'ARS', 'AUD', 'EUR'];

// Campos por entidad (meta keys = keys del payload)
const HIPPO_CRM_CLIENTE_CAMPOS  = ['contacto', 'telefono', 'pais'];
// `unidad`: nombre de la unidad si el proyecto se cobra por unidad (ej. 'casilla'); vacío = cobro normal
const HIPPO_CRM_PROYECTO_CAMPOS = ['estado', 'fecha_inicio', 'deadline', 'tipo_proyecto', 'valor', 'frecuencia_pago', 'unidad'];
const HIPPO_CRM_UNIDAD_CAMPOS   = ['fecha_alta', 'fecha_baja'];
const HIPPO_CRM_TAREA_ESTADOS     = ['PENDIENTE', 'EN_CURSO', 'BLOQUEADA', 'HECHA'];
const HIPPO_CRM_TAREA_PRIORIDADES = ['ALTA', 'MEDIA', 'BAJA'];
const HIPPO_CRM_PAGO_CAMPOS     = ['fecha', 'monto', 'medio_pago'];
const HIPPO_CRM_COSTO_CAMPOS    = ['monto', 'metodo_pago', 'frecuencia', 'fecha_renovacion', 'fecha_inicio', 'fecha_baja', 'categoria'];
const HIPPO_CRM_COSTO_CATEGORIAS = ['SUELDO', 'SUSCRIPCION', 'HOSTING', 'SERVICIO', 'IMPUESTO', 'OTRO'];
// periodo: 'YYYY-MM' (mensual y semanal) o 'YYYY' (anual): qué cubre el pago, no cuándo se hizo
const HIPPO_CRM_PAGO_COSTO_CAMPOS = ['fecha', 'periodo', 'monto', 'metodo_pago'];

// Guarda los campos presentes en $params. null o '' BORRAN el meta:
// antes se usaba isset(), que ignora los null, y no se podía vaciar un campo
// (ej. sacar un deadline desde el CRM no tenía efecto).
function hippo_crm_save_meta($post_id, $params, $fields, $sanitize = 'sanitize_text_field') {
    foreach ($fields as $f) {
        if (!array_key_exists($f, $params)) continue;
        $valor = $params[$f];
        if ($valor === null || $valor === '') {
            delete_post_meta($post_id, $f);
            continue;
        }
        update_post_meta($post_id, $f, call_user_func($sanitize, $valor));
    }
}

// Guarda la moneda solo si es válida (los endpoints validan antes con hippo_crm_moneda_param_invalida)
function hippo_crm_save_moneda($post_id, $params) {
    if (!array_key_exists('moneda', $params)) return;
    $moneda = $params['moneda'];
    if ($moneda === null || $moneda === '') {
        delete_post_meta($post_id, 'moneda');
    } elseif (in_array($moneda, HIPPO_CRM_MONEDAS, true)) {
        update_post_meta($post_id, 'moneda', $moneda);
    }
}

// Evita que un PUT con un ID cualquiera modifique otro tipo de post (páginas, posts, etc.)
function hippo_crm_get_post_of_type($id, $post_type) {
    $post = get_post((int) $id);
    return ($post && $post->post_type === $post_type) ? $post : null;
}

function hippo_crm_moneda_param_invalida($params) {
    return isset($params['moneda']) && $params['moneda'] !== '' && !in_array($params['moneda'], HIPPO_CRM_MONEDAS, true);
}
