<?php
// Hippo CRM — Proyectos

if (!defined('ABSPATH')) exit;

function hippo_crm_proyecto_to_array($post) {
    $cliente_id = (int) get_post_meta($post->ID, 'cliente_id', true);
    $cliente = get_post($cliente_id);
    return [
        'id'              => $post->ID,
        'nombre'          => $post->post_title,
        'clienteId'       => $cliente_id,
        'clienteNombre'   => $cliente ? $cliente->post_title : null,
        'estado'          => get_post_meta($post->ID, 'estado', true) ?: 'PROSPECTO',
        'fechaInicio'     => get_post_meta($post->ID, 'fecha_inicio', true) ?: null,
        'deadline'        => get_post_meta($post->ID, 'deadline', true) ?: null,
        'accionPendiente' => get_post_meta($post->ID, 'accion_pendiente', true) ?: null,
        'tipoProyecto'    => get_post_meta($post->ID, 'tipo_proyecto', true) ?: 'ON_OFF',
        'valor'           => (float) get_post_meta($post->ID, 'valor', true),
        'moneda'          => get_post_meta($post->ID, 'moneda', true) ?: null,
        'frecuenciaPago'  => get_post_meta($post->ID, 'frecuencia_pago', true) ?: null,
        // montoPendiente se quitó: lo calcula el CRM a partir de valor, moneda y pagos
        'url'             => get_post_meta($post->ID, 'url', true) ?: null,
        'unidad'          => get_post_meta($post->ID, 'unidad', true) ?: null,
        // Las unidades viajan con el proyecto: el CRM las necesita para calcular el saldo
        'unidades'        => get_post_meta($post->ID, 'unidad', true) ? hippo_crm_unidades_de($post->ID) : [],
    ];
}

function hippo_crm_get_proyectos() {
    $posts = get_posts(['post_type' => 'hippo_proyecto', 'numberposts' => -1]);
    return new WP_REST_Response(array_map('hippo_crm_proyecto_to_array', $posts), 200);
}

function hippo_crm_get_proyectos_by_cliente($request) {
    $posts = get_posts([
        'post_type' => 'hippo_proyecto', 'numberposts' => -1,
        'meta_key' => 'cliente_id', 'meta_value' => (int) $request->get_param('id'),
    ]);
    return new WP_REST_Response(array_map('hippo_crm_proyecto_to_array', $posts), 200);
}

function hippo_crm_get_proyecto($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_proyecto');
    if (!$post) return new WP_REST_Response(['error' => 'Proyecto no encontrado'], 404);
    return new WP_REST_Response(hippo_crm_proyecto_to_array($post), 200);
}

function hippo_crm_save_proyecto_meta($id, $params) {
    if (isset($params['cliente_id'])) update_post_meta($id, 'cliente_id', (int) $params['cliente_id']);
    hippo_crm_save_meta($id, $params, HIPPO_CRM_PROYECTO_CAMPOS);
    hippo_crm_save_meta($id, $params, ['accion_pendiente'], 'sanitize_textarea_field');
    hippo_crm_save_meta($id, $params, ['url'], 'esc_url_raw');
    hippo_crm_save_moneda($id, $params);
}

function hippo_crm_create_proyecto($request) {
    $params = $request->get_json_params();
    if (empty($params['cliente_id'])) return new WP_REST_Response(['error' => 'cliente_id es obligatorio'], 400);
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);

    $id = wp_insert_post(['post_type' => 'hippo_proyecto', 'post_title' => sanitize_text_field($params['nombre']), 'post_status' => 'publish']);
    hippo_crm_save_proyecto_meta($id, $params);
    return new WP_REST_Response(['id' => $id], 201);
}

function hippo_crm_update_proyecto($request) {
    $post = hippo_crm_get_post_of_type($request->get_param('id'), 'hippo_proyecto');
    if (!$post) return new WP_REST_Response(['error' => 'Proyecto no encontrado'], 404);

    $params = $request->get_json_params();
    if (hippo_crm_moneda_param_invalida($params)) return new WP_REST_Response(['error' => 'Moneda inválida'], 400);

    if (!empty($params['nombre'])) wp_update_post(['ID' => $post->ID, 'post_title' => sanitize_text_field($params['nombre'])]);
    hippo_crm_save_proyecto_meta($post->ID, $params);
    return new WP_REST_Response(['success' => true], 200);
}
